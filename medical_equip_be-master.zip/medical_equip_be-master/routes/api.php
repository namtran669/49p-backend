<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::post('/login', 'UserController@login');

Route::group(['middleware' => 'checkToken'], function () {
    Route::post('user/avatar', 'UserController@updateAvatar')->name('updateAvatar');
    Route::put('user/payment_info', 'UserController@updateUserPaymentInfo')->name('updateUserPaymentInfo');
    Route::put('user', 'UserController@updateUser')->name('updateUser');
    Route::get('favorite', 'UserController@getFavoriteProducts');
    Route::get('product_history', 'UserController@productHistory');
    Route::get('top_purchased', 'UserController@topPurchased');
    Route::post('add_favorite', 'UserController@addFavoriteProduct');
    Route::delete('delete_favorite/{id}', 'UserController@deleteFavoriteProduct');
    Route::post('/logout', 'UserController@logout')->name('logout');

    Route::get('all_category', 'CategoryController@allUserCategory')->name('category');

    Route::get('active_banner', 'BannerController@getActiveBanner')->name('banner');

    Route::get('product', 'ProductController@getProducts');
    Route::get('product/{id}', 'ProductController@getProduct');

    Route::get('combo', 'ComboController@getCombos');
    Route::get('combo/{id}', 'ComboController@getCombo');

    Route::get('blog', 'BlogController@getActiveBlog');
    Route::get('blog/{id}', 'BlogController@getBlog');

    Route::get('cart', 'CartController@cartContent');
    Route::post('cart', 'CartController@addCartItem');
    Route::put('cart/{rowId}', 'CartController@updateCartItem');
    Route::delete('cart/{rowId}', 'CartController@deleteCartItem');

    Route::post('payment', 'PaymentController@payment');
    Route::get('contact', 'SettingController@getContact');
    Route::post('send_message', 'ChatController@sendMessage');
    Route::get('order_history', 'OrderController@getUserOrderHistory');
    Route::get('fetch_message', 'ChatController@getMessagesByUser');

    Route::get('shipping_fee', 'DeliveryController@getShippingFee');

    Route::get('allVendor', 'VendorController@getAllVendorClient');
    Route::get('order/{id}', 'OrderController@orderDetail');
    Route::get('collections', 'ProductController@getCollections');
});
Route::post('updateShipment/' . config('delivery.secret'), 'DeliveryController@updateShipment');

Route::post('/admin/login', 'AdminController@login');
Route::group(['middleware' => 'jwt.auth'], function () {
    Route::post('/admin/logout', 'AdminController@logout');
    Route::get('/admin/dashboard', 'AdminController@dashboard');

//    Route::get('rank', 'RankController@index')->name('ranks');
//    Route::get('rank/{id}', 'RankController@getRank')->name('rank');
//    Route::put('rank/{id}', 'RankController@updateRank')->name('update_rank');

    Route::get('user', 'UserController@index')->name('user');
    Route::get('user/{id}', 'UserController@getUser')->name('user_detail');

    Route::get('admin/all_category', 'CategoryController@getAllCategory');
    Route::get('category', 'CategoryController@index')->name('category');
    Route::get('category/{id}', 'CategoryController@getCategory')->name('category_detail');
    Route::put('category/{id}', 'CategoryController@updateCategory')->name('update_category');
    Route::post('category/create', 'CategoryController@createCategory')->name('update_category');
    Route::delete('category/{id}', 'CategoryController@deleteCategory')->name('delete_category');

    Route::get('banner', 'BannerController@index')->name('banner');
    Route::get('banner/{id}', 'BannerController@getBanner')->name('banner_detail');
    Route::post('banner/create', 'BannerController@createBanner');
    Route::put('banner/{id}', 'BannerController@updateBanner');
    Route::delete('banner/{id}', 'BannerController@deleteBanner');

    Route::get('admin/product', 'ProductController@getProducts');
    Route::get('admin/product/{id}', 'ProductController@getProduct');
    Route::post('admin/product/create', 'ProductController@createProduct');
    Route::put('admin/product/{id}', 'ProductController@updateProduct');
    Route::delete('admin/product/{id}', 'ProductController@deleteProduct');

    Route::get('admin/combo', 'ComboController@getCombos');
    Route::get('admin/combo/{id}', 'ComboController@getCombo');
    Route::post('admin/combo/create', 'ComboController@createCombo');
    Route::put('admin/combo/{id}', 'ComboController@updateCombo');
    Route::delete('admin/combo/{id}', 'ComboController@deleteCombo');

    Route::get('admin/blog', 'BlogController@getBlogs');
    Route::get('admin/blog/{id}', 'BlogController@getBlog');
    Route::post('admin/blog/create', 'BlogController@createBlog');
    Route::put('admin/blog/{id}', 'BlogController@updateBlog');
    Route::delete('admin/blog/{id}', 'BlogController@deleteBlog');

    Route::post('admin/tinymce_upload', 'Controller@uploadTinymce');
    Route::get('admin/order', 'OrderController@getOrders');
    Route::get('admin/order/{id}', 'OrderController@getOrderDetails');
    Route::put('admin/order_status/{id}', 'OrderController@updateOrderPaymentStatus');
    Route::put('admin/shipping_status/{id}', 'OrderController@updateShippingStatus');
    Route::put('admin/fulfillment_status/{id}', 'OrderController@updateFulfillmentStatus');
    Route::delete('admin/order/{id}', 'OrderController@deleteOrder');

    Route::get('admin/setting', 'SettingController@getSettings');
    Route::get('admin/setting/{id}', 'SettingController@getSetting');
    Route::put('admin/setting/{id}', 'SettingController@updateSetting');

    Route::get('admin/user_chat', 'ChatController@getUserForChat');
    Route::get('admin/user_message', 'ChatController@getMessagesByUser');
    Route::post('admin/send_message', 'ChatController@sendMessage');

    Route::get('admin/allVendor', 'VendorController@getAllVendor');
    Route::get('admin/vendor', 'VendorController@index');
    Route::get('admin/vendor/{id}', 'VendorController@show');
    Route::post('admin/vendor/create', 'VendorController@store');
    Route::put('admin/vendor/{id}', 'VendorController@update');
    Route::delete('admin/vendor/{id}', 'VendorController@destroy');

    Route::get('admin/syncProduct', 'ShopifyController@syncProduct');
    Route::get('admin/syncCustomer', 'ShopifyController@syncCustomer');
    Route::get('admin/syncOrder', 'ShopifyController@syncOrder');
    Route::get('admin/syncCollection', 'ShopifyController@syncCollection');

});

