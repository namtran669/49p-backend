<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Cloudinary API configuration
    |--------------------------------------------------------------------------
    |
    | Before using Cloudinary you need to register and get some detail
    | to fill in below, please visit cloudinary.com.
    |
    */

    'cloudName'  => env('CLOUDINARY_CLOUD_NAME', 'dgxchxkvg'),
    'baseUrl'    => env('CLOUDINARY_BASE_URL', 'http://res.cloudinary.com/'.env('CLOUDINARY_CLOUD_NAME', 'dgxchxkvg')),
    'secureUrl'  => env('CLOUDINARY_SECURE_URL', 'https://res.cloudinary.com/'.env('CLOUDINARY_CLOUD_NAME', 'dgxchxkvg')),
    'apiBaseUrl' => env('CLOUDINARY_API_BASE_URL', 'https://api.cloudinary.com/v1_1/'.env('CLOUDINARY_CLOUD_NAME', 'dgxchxkvg')),
    'apiKey'     => env('CLOUDINARY_API_KEY', '391912995265325'),
    'apiSecret'  => env('CLOUDINARY_API_SECRET', 'PiXgabz1s282blWl97kuaf_ZELM'),

    'scaling'    => [
        'format' => 'png',
//        'width'  => 150,
//        'height' => 150,
        'crop'   => 'fit',
        'effect' => null
    ],

];
