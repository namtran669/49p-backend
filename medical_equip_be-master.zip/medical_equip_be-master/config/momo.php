<?php
return [
    'endpoint' => env('MOMO_ENDPOINT'),
    'access_key' => env('MOMO_ACCESS_KEY'),
    'secret_key' => env('MOMO_SECRET_KEY'),
    'partner_code' => env('MOMO_PARTNER_CODE'),
    'public_key' => "-----BEGIN PUBLIC KEY-----\r\n" . env('MOMO_PUBLIC_KEY') . "\r\n-----END PUBLIC KEY-----"
];
