<?php
return [
    'endpoint' => env('DELIVERY_ENDPOINT'),
    'token' => env('DELIVERY_TOKEN'),
    'secret' => env('DELIVERY_SHIPMENT_SECRETE')
];
