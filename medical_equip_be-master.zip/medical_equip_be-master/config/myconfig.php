<?php
return [
    'adminId' => env('ADMIN_ID'),
];
