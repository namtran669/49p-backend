<?php
return [
    'endpoint' => env('SHOPIFY_ENDPOINT')
];
