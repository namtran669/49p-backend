<?php

namespace App;

use Carbon\Carbon;
use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $table = 'orders';

    protected $fillable = [
        'order_code',
        'trans_id',
        'payment_status',
        'total_amount',
        'total_discount',
        'user_id',
        'shipping_date',
        'shipping_status',
        'pay_method',
        'delivery_code',
        'name',
        'phone',
        'address',
        'provincial',
        'district',
        'shopify_id',
        'shopify_user_id',
        'total_weight',
        'fulfillment_status',
        'gateway',
        'fulfillment_date',
        'cancelled_at',
        'cancel_reason'
    ];

    protected $casts = [
        'total_amount' => 'double',
        'total_discount' => 'double',
    ];

    protected $appends = [
        'pay_status_name',
        'status_name'
    ];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'trans_id',
        'shopify_id',
        'shopify_user_id',
        'delivery_code',
        'shipping_date',
    ];

    const PAYMENT_STATUS_YES = 1;
    const PAYMENT_STATUS_NO = 0;

    const STATUS_NEW = 1;
    const STATUS_SHIPPING = 2;
    const STATUS_DONE = 3;
    const STATUS_CHANGE = 4;

    const PAY_METHOD_NORMAL = 1;
    const PAY_METHOD_BANK = 3;
    const PAY_METHOD_MOMO = 2;

    const PAY_STATUS_NAME = [
        self::PAYMENT_STATUS_NO => 'Chưa thanh toán',
        self::PAYMENT_STATUS_YES => 'Đã thanh toán'
    ];

    const PAY_METHOD_NAME = [
        self::PAY_METHOD_NORMAL => 'Cash on Delivery (COD)',
        self::PAY_METHOD_MOMO => 'Momo',
        self::PAY_METHOD_BANK => 'Bank Deposit',
    ];

    const STATUS_NAME = [
        self::STATUS_NEW => 'Chờ duyệt',
        self::STATUS_SHIPPING => 'Đang vận chuyển',
        self::STATUS_DONE => 'Đã hoàn thành',
        self::STATUS_CHANGE => 'Đã hủy',
    ];

    const MAP_DELIVERY_STATUS = [
        self::STATUS_NEW => [1, 2],
        self::STATUS_SHIPPING => [3, 4, 7, 8, 9, 10, 11, 12],
        self::STATUS_DONE => [5, 6],
        self::STATUS_CHANGE => [20, 21],
    ];

    public function details()
    {
        return $this->hasMany(OrderDetail::class);
    }

    public function getPayStatusNameAttribute()
    {
        return self::PAY_STATUS_NAME[$this->payment_status];
    }

    public function getStatus()
    {
        if ($this->cancelled_at) {
            return self::STATUS_CHANGE;
        }

        if (is_null($this->fulfillment_status)) {
            return self::STATUS_NEW;
        }

        $isFulfill = $this->fulfillment_date && Carbon::parse($this->fulfillment_date)->lessThanOrEqualTo(now()->subDays(10));

        if ($this->fulfillment_status === 'fulfilled' && $this->payment_status == 1 && $isFulfill) {
            return self::STATUS_DONE;
        }

        return self::STATUS_SHIPPING;
    }

    public function getStatusNameAttribute()
    {
        return self::STATUS_NAME[$this->getStatus()];
    }

    public function userPaymentInfo()
    {
        return $this->belongsTo(UserPayment::class, 'user_id', 'user_id');
    }

    public function user()
    {
        return $this->belongsTo(User::class);
    }
}
