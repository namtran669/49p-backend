<?php

namespace App;

use Illuminate\Foundation\Auth\User as Authenticatable;
use Illuminate\Notifications\Notifiable;

class User extends Authenticatable
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'email',
        'password',
        'phone',
        'token',
        'address',
        'avatar',
        'img_public_id',
        'total_amount_spent',
        'type',
        'channel',
        'password',
        'accepts_marketing',
        'shopify_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'password', 'remember_token', 'token', 'shopify_id', 'img_public_id',
    ];

    /**
     * The attributes that should be cast to native types.
     *
     * @var array
     */
    protected $casts = [
        'email_verified_at' => 'datetime',
        'total_amount_spent' => 'double'
    ];

    public function rank()
    {
        return $this->belongsTo(Rank::class);
    }

    public function isAdmin()
    {
        return $this->type === 1;
    }

    public function favoriteProducts()
    {
        return $this->belongsToMany(Product::class);
    }

    public function paymentInfo()
    {
        return $this->hasOne(UserPayment::class);
    }
}
