<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserPayment extends Model
{
    protected $table = 'user_payments';

    protected $fillable = [
        'user_id',
        'email',
        'name',
        'phone',
        'address',
        'provincial',
        'district',
        'ward',
        'street'
    ];
    public $timestamps = false;
}
