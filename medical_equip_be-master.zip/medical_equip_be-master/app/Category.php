<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $table = 'categories';

    const TYPE_PRODUCT = 1;
    const TYPE_BLOG = 2;

    protected $fillable = [
        'name',
        'type',
        'icon',
        'img_public_id'
    ];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'img_public_id'
    ];
}
