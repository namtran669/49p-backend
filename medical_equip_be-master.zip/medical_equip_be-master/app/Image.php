<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Image extends Model
{
    protected $table = 'images';

    protected $fillable = [
        'src',
        'img_public_id',
        'is_avatar',
        'combo_id',
        'product_id',
        'shopify_id',
    ];
    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'img_public_id'
    ];
}
