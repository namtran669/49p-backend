<?php

namespace App\Http\Controllers;

use App\Order;
use App\Service\DeliveryService;
use App\Service\OrderService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;

class OrderController extends Controller
{
    private $order_service;

    public function __construct(OrderService $order_service)
    {
        $this->order_service = $order_service;
    }

    public function getOrders(Request $request)
    {
        return $this->responseSuccess($this->order_service->getOrders($request));
    }

    public function getOrderDetails($id)
    {
        $order = $this->order_service->getOrder($id);
        if (empty($order)) {
            return $this->responseError('Đơn hàng không tồn tại', Response::HTTP_NOT_FOUND);
        }
        $order_details = $order->details;
        $responseData = [
            'details' => $order_details,
            'paymentStatus' => $order->payment_status,
            'shippingStatus' => $order->shipping_status,
        ];
        return $this->responseSuccess($responseData);
    }

    public function updateOrderPaymentStatus(Request $request, $id)
    {
        $rules = [
            'paymentStatus' => 'required|in:1'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        $order = $this->order_service->getOrder($id);
        if (empty($order)) {
            return $this->responseError("Đơn hàng không tồn tại", Response::HTTP_NOT_FOUND);
        }

        if ($order->payment_status === Order::PAY_METHOD_NORMAL) {
            return $this->responseError("Chỉ có thể thay đổi trạng thái thanh toán của đơn hàng thanh toán trực tiếp", parent::UPDATE_DATA_PERMISSION_ERROR);
        }

        $this->order_service->updateOrderPaymentStatus($order, intval($request->get('paymentStatus')));
        return $this->responseSuccess($this->order_service->getOrders($request));
    }

    public function updateShippingStatus(Request $request, $id)
    {
        $rules = [
            'shippingStatus' => 'required|in:1,2,3'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        $order = $this->order_service->getOrder($id);
        if (empty($order)) {
            return $this->responseError("Đơn hàng không tồn tại", Response::HTTP_NOT_FOUND);
        }

        $this->order_service->updateOrderShippingStatus($order, intval($request->get('shippingStatus')));
        return $this->responseSuccess($this->order_service->getOrders($request));
    }

    public function updateFulfillmentStatus(Request $request, $id)
    {

        $order = $this->order_service->getOrder($id);
        if (empty($order)) {
            return $this->responseError("Đơn hàng không tồn tại", Response::HTTP_NOT_FOUND);
        }

        $order->update([
            'fulfillment_status' => $request->input('fulfillmentStatus')
        ]);
        return $this->responseSuccess($this->order_service->getOrders($request));
    }

    public function deleteOrder(Request $request, $id)
    {
        $order = $this->order_service->getOrder($id);
        if (empty($order)) {
            return $this->responseError("Đơn hàng không tồn tại", Response::HTTP_NOT_FOUND);
        }
        if ($order->payment_status !== Order::PAYMENT_STATUS_NO || $order->shipping_status !== Order::STATUS_NEW) {
            return $this->responseError("Không thể xóa đơn hàng đã thanh toán hoặc đã giao", parent::UPDATE_DATA_PERMISSION_ERROR);
        }

        $deliveryService = new DeliveryService();
        $response = $deliveryService->cancelOrder($order->delivery_code);
        if ($response['success']) {
            $this->order_service->deleteOrder($id);
            return $this->responseSuccess($this->order_service->getOrders($request));
        } else {
            return $this->responseError($response['message'], self::ERROR);
        }
    }

    public function getUserOrderHistory(Request $request) {
        return $this->responseSuccess($this->order_service->getOrderByUserId($request, Auth::id()));
    }

    public function orderDetail($orderId)
    {
        $order = Order::where('id', $orderId)->first();

        if (empty($order) || $order->user_id != Auth::id()) {
            return $this->responseError('Đơn hàng không tòn tại', 404);
        }

        $orderDetails = $order->details->map(function ($orderDetail) {
            return collect($orderDetail)->merge([
                'item' => collect($orderDetail->product)->merge(['variant' => $orderDetail->variant->load('image')])
            ]);
        });

        return $this->responseSuccess($orderDetails->toArray());
    }
}
