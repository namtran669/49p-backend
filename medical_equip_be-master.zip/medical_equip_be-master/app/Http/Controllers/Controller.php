<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Support\Str;
use JD\Cloudder\Facades\Cloudder;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;

    const SUCCESS = 1;
    const ERROR = 2;
    const VALIDATE_ERROR = 3;
    const CART_UPDATED_ERROR = 4;
    const UPDATE_DATA_PERMISSION_ERROR = 5;
    const ITEM_PER_PAGE = 12;

    protected function responseSuccess($data, $messages = '', $headers = [])
    {
        $data_response = [
            'code' => Response::HTTP_OK,
            'message' => $messages,
            'data' => $data
        ];
        $headers[] = ['Content-Type' => 'application/json'];
        return response()->json($data_response)
            ->withHeaders($headers);
    }

    protected function responseError($messages, $error_code)
    {
        $data_response = [
            'code' => $error_code,
            'message' => $messages,
            'data' => null
        ];
        return response()->json($data_response);
    }

    protected function destroyImg($public_id) {
        if ($public_id) {
            Cloudder::delete($public_id);
        }
    }

    public function uploadTinymce(Request $request)
    {
        if ($request->hasFile('file')) {
            $file = $request->file;
            $public_id = Str::random(10);
            Cloudder::upload($file, "uploads/tinymce/$public_id");
            $src = Cloudder::show(Cloudder::getPublicId());
            return response()->json(['location' => $src]);
        }
        return response()->json(['location' => '']);
    }
}
