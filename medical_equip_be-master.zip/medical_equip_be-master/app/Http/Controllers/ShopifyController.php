<?php

namespace App\Http\Controllers;

use App\Service\SyncService;

class ShopifyController extends Controller
{
    protected $syncService;

    public function __construct(SyncService $syncService)
    {
        $this->syncService = $syncService;
    }

    public function syncProduct()
    {
        set_time_limit(1800);
        $count = $this->syncService->syncProduct();
        $this->syncService->initQuery();
        $this->syncService->syncCollection();

        return $this->responseSuccess([
            'count' => 1
        ]);
    }

    public function syncCustomer()
    {
        set_time_limit(1800);

        return $this->responseSuccess([
            'count' => $this->syncService->syncCustomer()
        ]);
    }

    public function syncOrder()
    {
        set_time_limit(1800);

        return $this->responseSuccess([
            'count' => $this->syncService->syncOrder()
        ]);
    }

    /**
     * @return ShopifyController
     * @throws \Exception
     */
    public function syncCollection()
    {
        set_time_limit(1800);
        return $this->responseSuccess([
            'count' => $this->syncService->syncCollection()
        ]);
    }

}
