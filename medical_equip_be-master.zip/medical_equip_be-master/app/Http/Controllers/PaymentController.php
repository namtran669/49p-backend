<?php

namespace App\Http\Controllers;

use App\Exceptions\ShopifyException;
use App\Order;
use App\Service\CartService;
use App\Service\DeliveryService;
use App\Service\MomoService;
use App\Service\OrderService;
use App\Service\ShopifyService;
use App\Service\UserService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class PaymentController extends Controller
{
    private $cart_service;
    private $order_service;
    private $cart_content;
    private $user_service;
    private $error;

    public function __construct(CartService $cart_service, OrderService $order_service, UserService $user_service)
    {
        $this->cart_service = $cart_service;
        $this->order_service = $order_service;
        $this->user_service = $user_service;
        $this->error = '';
    }

    public function payment(Request $request)
    {
        $this->cart_content = $this->cart_service->getCarts();
        $pay_methods = [
            Order::PAY_METHOD_NORMAL,
            Order::PAY_METHOD_MOMO,
            Order::PAY_METHOD_BANK,
        ];
        $rules = [
            'payMethod' => 'required|in:' . implode(',', $pay_methods),
            'total' => 'required',
            'phone' => 'required',
            'name' => 'required',
            'address' => 'required',
            'provincial' => 'required',
            'ward' => 'required',
            'district' => 'required',
            'shippingFee' => 'required'
        ];
        $payMethod = intval($request->get('payMethod'));
        if ($payMethod === Order::PAY_METHOD_MOMO) {
            $rules['momo_phone'] = 'required';
            $rules['momo_appdata'] = 'required';
        }
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        if (empty($this->cart_content['items'])) {
            return $this->responseError('Không có sản phẩm để thanh toán', Response::HTTP_NOT_FOUND);
        }

        if ($this->cart_content['total'] != $request->get('total')) {
            return $this->responseError('Giỏ hàng đã thay đổi. Hãy xem lại giỏ hàng', parent::CART_UPDATED_ERROR);
        }

        switch ($payMethod) {
            case Order::PAY_METHOD_MOMO:
                $this->payByMomo($request->all());
                break;
            case Order::PAY_METHOD_BANK:
                $this->payByBank($request->all());
                break;
            default:
                $this->payByNormal($request->all());
        }

        if (empty($this->error)) {
            $this->cart_service->destroyCart();
            return $this->responseSuccess([]);
        }
        return $this->responseError($this->error, parent::ERROR);
    }

    private function payByNormal(array $payment_info)
    {
        DB::beginTransaction();
        try {
            $order = $this->order_service->createOrder($this->cart_content, Order::PAY_METHOD_NORMAL, Order::PAYMENT_STATUS_NO, $payment_info);
            $shopifyOrder = $this->order_service->createShopifyOrder($order);
            if ($shopifyOrder) {
                Cache::put('shopify_id', $shopifyOrder['id'], 1);
                $this->order_service->updateShopifyOrder($order, $shopifyOrder);

                $response = $this->registerOrder($order);
                if ($response['success']) {
                    $order->delivery_code = $response['order']['label'];
                    $order->save();
                    DB::commit();
                    return $order;
                }

                $this->rollbackShopifyOrder(Cache::get('shopify_id'));
                $this->error = $response['message'];
            }

            Cache::forget('shopify_id');
            DB::rollBack();
            return false;
        } catch (\Exception $exception) {
            Log::info($exception->getMessage());

            $this->rollbackShopifyOrder(Cache::get('shopify_id'));
            Cache::forget('shopify_id');

            DB::rollBack();
            $this->error = 'Không thể tạo đơn hàng';

            return false;
        }
    }

    private function payByBank(array $payment_info)
    {
        DB::beginTransaction();
        try {
            $order = $this->order_service->createOrder($this->cart_content, Order::PAY_METHOD_BANK, Order::PAYMENT_STATUS_NO, $payment_info);
            $shopifyOrder = $this->order_service->createShopifyOrder($order);

            if ($shopifyOrder) {
                Cache::put('shopify_id', $shopifyOrder['id'], 1);
                $this->order_service->updateShopifyOrder($order, $shopifyOrder);

                DB::commit();
                return $order;
            }

            Cache::forget('shopify_id');
            DB::rollBack();
            return false;
        } catch (\Exception $exception) {
            Log::info($exception->getMessage());

            $this->rollbackShopifyOrder(Cache::get('shopify_id'));
            Cache::forget('shopify_id');

            DB::rollBack();
            $this->error = 'Không thể tạo đơn hàng';

            return false;
        }
    }

    private function payByMomo(array $paymentInfo)
    {
        $orderCode = Str::random(15);
        $json_string = json_encode([
            'partnerCode' => config('momo.partner_code'),
            'partnerRefId' => $orderCode,
            'amount' => intval($paymentInfo['total'] + $paymentInfo['shippingFee'])
        ]);
        if (openssl_public_encrypt($json_string, $encrypted, config('momo.public_key'))){
            $hash = base64_encode($encrypted);
            $data = [
                'partnerCode' => config('momo.partner_code'),
                'partnerRefId' => $orderCode,
                'customerNumber' => $paymentInfo['momo_phone'],
                'appData' => $paymentInfo['momo_appdata'],
                'hash' => $hash,
                'version' => 2.0,
                'payType' => 3,
                'description' => ' Thanh toán mua hàng app nha khoa'
            ];
            $momoService = new MomoService();
            $response = $momoService->requestPayment($data)->getBody();
            $response = json_decode($response, true);
            if ($response['status'] !== 0) {
                $this->error = $response['message'];
                return false;
            }

            $requestId = Str::random(15);
            $confirmData = [
                'partnerCode' => config('momo.partner_code'),
                'partnerRefId' => $orderCode,
                'requestType' => 'capture',
                'requestId' => $requestId,
                'momoTransId' => $response['transid'],
            ];

            DB::beginTransaction();

            try {
                $paymentInfo['trans_id'] = $response['transid'];
                $order = $this->order_service->createOrder($this->cart_content, Order::PAY_METHOD_NORMAL, Order::PAYMENT_STATUS_NO, $paymentInfo);
                $shopifyOrder = $this->order_service->createShopifyOrder($order);
                if ($shopifyOrder) {
                    Cache::put('shopify_id', $shopifyOrder['id'], 1);
                    $this->order_service->updateShopifyOrder($order, $shopifyOrder);
                    $orderResponse = $this->registerOrder($order);

                    //confirm
                    $confirmData['signature'] = $this->getSignature($confirmData);
                    $confirmResponse = json_decode($momoService->confirmPayment($confirmData)->getBody(), true);

                    if ($confirmResponse['status'] === 0 && $orderResponse['success']) {
                        $order->delivery_code = $orderResponse['order']['label'];
                        $order->save();
                        $this->order_service->updateTotalSpent($order);
                        DB::commit();
                        return $order;
                    } else if ($orderResponse['success']){
                        $deliveryService = new DeliveryService();
                        $deliveryService->cancelOrder($order->delivery_code);
                    }

                    $this->error = $confirmResponse['message'];
                    $this->rollbackShopifyOrder(Cache::get('shopify_id'));
                }


                $this->rollBackPayment($momoService, $confirmData);
                DB::rollBack();
                Cache::forget('shopify_id');
                return false;
            } catch (\Exception $exception) {
                Log::info($exception->getMessage());

                $this->rollBackPayment($momoService, $confirmData);
                $this->rollbackShopifyOrder(Cache::get('shopify_id'));
                Cache::forget('shopify_id');

                DB::rollBack();
                $this->error = 'Không thể tạo hóa đơn';
            }
        }

        return false;

    }

    private function getSignature($confirmData)
    {
        $str = '';
        foreach ($confirmData as $key => $value) {
            $str .= "$key=$value&";
        }
        $str = trim($str, '&');
        return hash_hmac('sha256', $str, config('momo.secret_key'));
    }

    private function rollBackPayment(MomoService $momoService, $confirmData)
    {
        $confirmData['requestType'] = 'revertAuthorize';
        $confirmData['signature'] = $this->getSignature($confirmData);
        $momoService->confirmPayment($confirmData);
    }

    private function registerOrder(Order $order)
    {
        $deliveryService = new DeliveryService();
        $products = [];
        foreach ($this->cart_content['items'] as $item) {
            $products[] = [
                'name' => $item['item']['name'],
                'weight' => $item['item']['weight'] / 1000,
                'quantity' => $item['qty'],
                'price' => $item['item']['variant']['price']
            ];
        }

        $postOrder = Cache::get('delivery_info');
        $postOrder = array_merge($postOrder, [
            'id' => $order->order_code,
            'pick_money' => $order->pay_method === Order::PAY_METHOD_NORMAL ? $order->total_amount : 0,
            'value' => $order->pay_method === Order::PAY_METHOD_NORMAL ? $order->total_amount : 1,
            'name' => $order->name,
            'address' => $order->address,
            'province' => $order->provincial,
            'district' => $order->district,
            'ward' => $order->ward,
            'street' => $order->street,
            'hamlet' => 'Khác',
            'tel' => $order->phone,
            'return_name' => $postOrder['pick_name'],
            'return_address' => $postOrder['pick_address'],
            'return_province' => $postOrder['pick_province'],
            'return_district' => $postOrder['pick_district'],
            'return_tel' => $postOrder['pick_tel'],
            'is_freeship' => $order->pay_method === Order::PAY_METHOD_NORMAL ? 0 : 1,
            'total_weight' => $this->cart_content['weight'] / 1000 < 0.5 ? 0.5 : $this->cart_content['weight'] / 1000
        ]);

        $data = [
            'products' => $products,
            'order' => $postOrder
        ];

        return $deliveryService->registerOrder($data);

    }

    protected function rollbackShopifyOrder($shopify_id)
    {
        if ($shopify_id) {
            $shopifyService = new ShopifyService();
            $shopifyService->deleteOrder($shopify_id);
        }
    }
}
