<?php

namespace App\Http\Controllers;

use App\Order;
use App\Service\CartService;
use App\Service\DeliveryService;
use App\Service\OrderService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\Validator;

class DeliveryController extends Controller
{
    private $deliveryService;
    private $cartService;
    private $deliveryInfo;

    public function __construct(DeliveryService $deliveryService, CartService $cartService)
    {
        $this->deliveryService = $deliveryService;
        $this->cartService = $cartService;
        $this->deliveryInfo = Cache::get('delivery_info');
    }

    public function getShippingFee(Request $request)
    {
        $rule = [
            'address' => 'required',
            'province' => 'required',
            'district' => 'required',
        ];

        $validator = Validator::make($request->all(), $rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $cart = $this->cartService->getCarts();

        $data = array_merge($request->all(), $this->deliveryInfo, ['weight' => $cart['weight'] ? $cart['weight'] : 500, 'value' => intval($cart['total'])]);

        $response = $this->deliveryService->getShippingFee($data);
        if (!empty($response) && $response['success']) {
            return $this->responseSuccess($response['fee']);
        }

        return $this->responseError($response['message'], Controller::ERROR);
    }

    public function updateShipment(Request $request)
    {
        $orderService = new OrderService();
        $order = $orderService->getOrderByDeliveryCode($request->get('label_id'));
        $requestStatus = intval($request->get('status_id'));
        if (empty($order) && $requestStatus !== -1) {
            return response()->json(['success' => false, 'message' => 'Đơn hàng không tồn tại'], Response::HTTP_NOT_FOUND);
        } else if (empty($order) && $requestStatus === -1) {
            return response()->json(['success' => true, 'message' => ''], Response::HTTP_OK);
        }
        $requestStatus = intval($request->get('status_id'));
        if ($requestStatus === -1) {
            $order->delete();
        }
        foreach (Order::MAP_DELIVERY_STATUS as $status => $delivery_status) {
            if (in_array($requestStatus, $delivery_status) && $order->shipping_status !== Order::STATUS_DONE) {
                $order->shipping_status = $status;
                break;
            }
        }
        $order->save();
        return response()->json(['success' => true, 'message' => ''], Response::HTTP_OK);
    }
}
