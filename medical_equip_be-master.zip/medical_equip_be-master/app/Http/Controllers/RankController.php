<?php

namespace App\Http\Controllers;

use App\Rank;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class RankController extends Controller
{
    public function index()
    {
        return $this->responseSuccess(Rank::all());
    }

    public function getRank($id)
    {
        $rank = $this->getRankById($id);
        if (empty($rank)) {
            return $this->responseError('Cấp thành viên không tồn tại', Response::HTTP_NOT_FOUND);
        }
        return $this->responseSuccess($rank);
    }

    public function updateRank(Request $request, $id)
    {
        $rules = [
            'turnover_condition' => 'numeric|min:0',
            'discount' => 'numeric|min:0'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        $rank = $this->getRankById($id);
        if (empty($rank)) {
            return $this->responseError('Cấp thành viên không tồn tại', Response::HTTP_NOT_FOUND);
        }
        $rank->turnover_condition = $request->get('turnover_condition');
        $rank->discount = $request->get('discount');
        $rank->save();

        return $this->responseSuccess($this->getRankById($id));
    }

    private function getRankById($id)
    {
        return Rank::query()->where('id', $id)->first();
    }
}
