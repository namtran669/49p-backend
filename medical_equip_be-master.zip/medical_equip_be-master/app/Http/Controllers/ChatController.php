<?php

namespace App\Http\Controllers;

use App\Message;
use App\Service\ChatService;
use App\Service\UserService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Log;
use Salman\Mqtt\MqttClass\Mqtt;

class ChatController extends Controller
{
    private $chat_service;
    private $user_service;

    public function __construct(ChatService $chat_service, UserService $user_service)
    {
        $this->chat_service = $chat_service;
        $this->user_service = $user_service;
    }

    public function getMessagesByUser(Request $request)
    {
        if (Auth::user()->isAdmin()) {
            $channel = $request->get('channel');
            if (empty($channel)) {
                return $this->responseError('Hội thoại không tồn tại', Response::HTTP_NOT_FOUND);
            }
        } else {
            $channel = Auth::user()->channel;
            if (empty($channel)) {
                $channel = $this->chat_service->createChannel(Auth::user());
            }
        }
        $lastId = $request->get('lastId', null);

        $messages = $this->chat_service->getMessagesByChannel($channel, $lastId);
        $returnMessages = [];
        foreach ($messages as $message)
        {
            $messageItem = $this->makeMessage($message);
            $returnMessages[] = $messageItem;
        }

        return $this->responseSuccess(array_reverse($returnMessages));
    }

    public function sendMessage(Request $request)
    {
        try {
            $output = false;
            if (!empty($request->get('message'))) {
                if (Auth::user()->isAdmin()) {
                    $channel = $request->get('channel');
                } else {
                    $channel = Auth::user()->channel;
                }

                $message = $this->chat_service->createMessage($channel, $request->get('message'), Auth::id());

                $from = [
                    'id' => Auth::user()->id,
                    'name' => Auth::user()->name,
                    'avatar' => Auth::user()->avatar,
                    'channel' => $channel
                ];
                $messageItem = $this->makeMessage($message, $from);
                $mqtt = new Mqtt();
                $output = $mqtt->ConnectAndPublish('admin_channel/' . $channel, json_encode($messageItem));
            }
            return $this->responseSuccess(['is_success' => $output]);
        } catch (\Exception $e) {
            return $this->responseError('Không thể gửi tin nhắn', Controller::ERROR);
        }

    }

    public function getUserForChat(Request $request)
    {
        return $this->responseSuccess($this->user_service->getUserForChat($request));
    }

    private function makeMessage(Message $message, $from = []) {
        $messageItem = [
            'id' => $message->id,
            'content' => $message->message,
            'myself' => $message->user_id === Auth::id(),
            'participantId' => $message->user_id,
            'from' => $from,
            'isAdmin' => $message->user_id === intval(config('myconfig.adminId')),
            'timestamp' => [
                'year' => Carbon::parse($message->created_at)->year,
                'month' => Carbon::parse($message->created_at)->month,
                'day' => Carbon::parse($message->created_at)->day,
                'hour' => Carbon::parse($message->created_at)->hour,
                'minute' => Carbon::parse($message->created_at)->minute,
                'second' => Carbon::parse($message->created_at)->second,
                'millisecond' => 0,
            ],
            'timestampString' => Carbon::parse($message->created_at)->format('Y-m-d H:i')
        ];
        return $messageItem;
    }
}
