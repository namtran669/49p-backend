<?php

namespace App\Http\Controllers;

use App\Combo;
use App\Product;
use App\Service\CartService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class CartController extends Controller
{
    private $cart_service;

    public function __construct(CartService $cart_service)
    {
        $this->cart_service = $cart_service;
    }

    public function cartContent()
    {
        $carts = $this->cart_service->getCarts();
        return $this->responseSuccess($carts);
    }

    public function addCartItem(Request $request)
    {
        $rule = [
            'productId' => 'required',
            'productType' => 'required|integer|in:1,2',
            'qty' => 'required|integer|min:1',
            'variantId' => 'required_if:productType,1|integer'
        ];
        $validator = Validator::make($request->all(), $rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors()->first(), parent::VALIDATE_ERROR);
        }
        $product_id = $request->get('productId');
        $product_type = intval($request->get('productType'));

        if ($product_type === \App\Cart::TYPE_PRODUCT) {
            $product = Product::where('id', $product_id)->first();
        } else {
            $product = Combo::where('id', $product_id)->first();
        }

        if (empty($product)) {
            return $this->responseError('Sản phẩm không tồn tại', 404);
        }
        $qty = $request->get('qty');
        $variantId = $request->get('variantId', null);
        $cart = $this->cart_service->getCartItemByProduct($product_id, $product_type, $variantId);
        if (!empty($cart)) {
            $this->cart_service->updateCartItem($cart, $qty, true);
        } else {
            $this->cart_service->addCartItem($product_id, $product_type, $qty, $variantId);
        }

        return $this->responseSuccess($this->cart_service->getCarts());
    }

    public function updateCartItem(Request $request, $rowId)
    {
        $rule = [
            'qty' => 'required|integer|min:1'
        ];

        $validator = Validator::make($request->all(), $rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        $cart = $this->cart_service->getCartItem($rowId);
        if (empty($cart)) {
            return $this->responseError('Sản phẩm không tồn tại', Response::HTTP_NOT_FOUND);
        }

        $this->cart_service->updateCartItem($cart, $request->get('qty'));
        return $this->responseSuccess($this->cart_service->getCarts());
    }

    public function deleteCartItem($rowId)
    {
        $this->cart_service->deleteCartItem($rowId);
        return $this->responseSuccess($this->cart_service->getCarts());
    }
}
