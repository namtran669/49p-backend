<?php

namespace App\Http\Controllers;

use App\Setting;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Cache;

class SettingController extends Controller
{
    public function getSettings()
    {
        $setting = Setting::query()->where('key_name', '<>', 'money_to_point')->get();
        return $this->responseSuccess($setting);
    }

    public function getSetting($id)
    {
        $setting = Setting::query()->where('id', $id)->first();
        if (!empty($setting)) {
            return $this->responseSuccess($setting);
        }
        return $this->responseError("Cài đặt không tồn tại", Response::HTTP_NOT_FOUND);
    }

    public function updateSetting(Request $request, $id)
    {
        $setting = Setting::query()->where('id', $id)->first();
        if (empty($setting)) {
            return $this->responseError("Cài đặt không tồn tại", Response::HTTP_NOT_FOUND);
        }
        $setting->value = $request->get('value');
        $setting->save();
        if ($setting->key_name === 'delivery_info') {
            $delivery_info = array_map(function ($item) {
                return $item['value'];
            }, json_decode($request->get('value'), true));
            Cache::forever('delivery_info', $delivery_info);
        }
        return $this->responseSuccess($setting);
    }

    public function getContact()
    {
        $setting = Setting::query()->where('key_name', 'contact')->first();
        if (!empty($setting)) {
            return $this->responseSuccess($setting->value);
        }
        return $this->responseError("Cài đặt không tồn tại", Response::HTTP_NOT_FOUND);
    }
}
