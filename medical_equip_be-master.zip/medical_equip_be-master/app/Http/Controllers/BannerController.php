<?php

namespace App\Http\Controllers;

use App\Banner;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use JD\Cloudder\Facades\Cloudder;

class BannerController extends Controller
{
    public function index()
    {
        $banners = Banner::query()->paginate(parent::ITEM_PER_PAGE);

        return $this->responseSuccess($banners);
    }

    public function getActiveBanner()
    {
        $banners = Banner::query()->where('is_show', 1)->get();
        return $this->responseSuccess($banners);
    }

    public function getBanner($id) {
        $banner = $this->getBannerById($id);
        if (empty($banner)) {
            return $this->responseError('Banner không tồn tại', Response::HTTP_NOT_FOUND);
        }
        return $this->responseSuccess($banner);
    }


    public function updateBanner(Request $request, $id)
    {
        $banner = $this->getBannerById($id);
        if (empty($banner)) {
            return $this->responseError('Banner không tồn tại', Response::HTTP_NOT_FOUND);
        }
        $rules = [
            'name' => 'required|unique:banners,name,' . $id
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $this->saveBanner($request, $banner);
        return $this->responseSuccess($this->getBannerById($id));
    }

    public function createBanner(Request $request)
    {
        $rules = [
            'name' => 'required|unique:banners'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $banner = new Banner();
        $this->saveBanner($request, $banner);
        return $this->responseSuccess($this->getBannerById($banner->id));
    }

    private function saveBanner(Request $request, $banner)
    {
        $banner->name = $request->get('name');
        $banner->is_show = $request->get('is_show', 1);
        if ($request->hasFile('img')) {
            $file = $request->img;
            if ($banner->img_public_id) {
                $this->destroyImg($banner->img_public_id);
            }
            $public_id = Str::random(10);
            Cloudder::upload($file, "uploads/banners/$public_id");
            $banner->src = Cloudder::show(Cloudder::getPublicId());
            $banner->img_public_id = "uploads/banners/$public_id";
        }
        $banner->save();
    }

    public function deleteBanner($id){
        $banner = $this->getBannerById($id);
        if (empty($banner)) {
            return $this->responseError('Banner không tồn tại', Response::HTTP_NOT_FOUND);
        }
        $this->destroyImg($banner->img_public_id);
        $banner->delete();
        return $this->responseSuccess([]);
    }


    private function getBannerById($id)
    {
        return Banner::query()->where('id', $id)->first();
    }
}
