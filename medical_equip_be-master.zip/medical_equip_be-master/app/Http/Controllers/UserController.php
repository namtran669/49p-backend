<?php

namespace App\Http\Controllers;

use App\Service\UserService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use JD\Cloudder\Facades\Cloudder;


class UserController extends Controller
{
    private $user_service;

    public function __construct()
    {
        $this->user_service = new UserService();
    }

    public function index(Request $request) {
        $users = $this->user_service->getUsers($request);
        return $this->responseSuccess($users);

    }

    public function getUser($id)
    {
        $user = $this->user_service->getUser($id);
        if (!empty($user)) {
            return $this->responseSuccess($user);
        }
        return $this->responseError("Thành viên không tồn tại", Response::HTTP_NOT_FOUND);
    }

    public function login(Request $request)
    {
        $rules = [
            'phone' => 'required'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        $user = $this->user_service->getUserByPhone($request->get('phone'));

        if (empty($user)) {
            $user = $this->user_service->createUser($request->get('phone'));
            $token = $user->token;
        } else {
            $token = Str::random(64);
            $user = $this->user_service->updateUser($user->id, ['token' => $token]);
        }

        $data = [
            'token' => $token,
            'data' => $user
        ];

        return $this->responseSuccess($data);
    }

    public function logout()
    {
        $this->user_service->updateUser(Auth::id(), ['token' => '']);
        Auth::logout();
        return $this->responseSuccess([]);
    }

    public function updateUser(Request $request) {
        $rules = [
            'email' => 'email',
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        $user = $this->user_service->updateUser(Auth::id(), $request->all());
        return $this->responseSuccess($user);
    }

    public function updateAvatar(Request $request)
    {
        $user = $this->user_service->getUser(Auth::id());
        if ($request->hasFile('avatar_img')) {
            $file = $request->avatar_img;
            if ($user->img_public_id) {
                $this->destroyImg($user->img_public_id);
            }
            $public_id = Str::random(10);
            Cloudder::upload($file, "uploads/avatar/$public_id");
            $src = Cloudder::show(Cloudder::getPublicId());
            $user = $this->user_service->updateUser($user->id, ['avatar' => $src, 'img_public_id' => "uploads/avatar/$public_id"]);
        }
        return $this->responseSuccess($user);
    }

    public function addFavoriteProduct(Request $request)
    {
        $rules = [
            'productId' => 'required|integer',
            'productType' => 'required|integer|in:1,2'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $product_id = intval($request->get('productId'));
        $product_type = intval($request->get('productType'));
        $this->user_service->addFavoriteProduct($product_id, $product_type, Auth::id());
        return $this->responseSuccess($this->user_service->getFavoriteProduct(Auth::id()));
    }

    public function deleteFavoriteProduct($id)
    {
        $this->user_service->deleteFavoriteProduct($id, Auth::id());
        return $this->responseSuccess($this->user_service->getFavoriteProduct(Auth::id()));
    }

    public function getFavoriteProducts()
    {
        return $this->responseSuccess($this->user_service->getFavoriteProduct(Auth::id()));
    }

    public function updateUserPaymentInfo(Request $request)
    {
        $user_payment = $this->user_service->updatePaymentInfo($request->all(), Auth::id());
        return $this->responseSuccess($user_payment);
    }

    public function productHistory()
    {
        return $this->responseSuccess(['data' => $this->user_service->getProductHistory()]);
    }

    public function topPurchased()
    {
        return $this->responseSuccess(['data' => $this->user_service->getProductHistory(true)]);
    }
}
