<?php

namespace App\Http\Controllers;

use App\Combo;
use App\Order;
use App\Product;
use App\Service\ChatService;
use App\User;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Validator;
use JWTAuth;
use JWTAuthException;

class AdminController extends Controller
{
    public function login(Request $request)
    {
        $rules = [
            'email' => 'required|email',
            'password' => 'required'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        $credentials = $request->only('email', 'password');
        $token = null;
        try {
            if (!$token = JWTAuth::attempt($credentials)) {
                return $this->responseError('Tài khoản không chính xác', self::ERROR);
            }
        } catch (JWTAuthException $e) {
            return $this->responseError('Không thể tạo token', Response::HTTP_INTERNAL_SERVER_ERROR);
        }
        return $this->responseSuccess([
            'token' => $token,
            'unreadMessageCount' => ChatService::getUnreadMessageCount()
        ]);
    }

    public function logout(Request $request)
    {
        $token = $request->header('Authorization');
        Auth::logout();
        JWTAuth::invalidate($token);
        return $this->responseSuccess([]);
    }

    public function dashboard()
    {
        $orders = Order::query()->whereDate('created_at', '>=', now()->startOfMonth()->toDateString())->get();
        $revenue = 0;
        $label = [];
        for ($month = 11; $month >= 0; $month--) {
            $label[] = Carbon::now()->subMonth($month)->format('Y-m');
        }
        $valueOrder = array_fill_keys($label, 0);
        $valueRevenue = array_fill_keys($label, 0);
        $label[11] = '';
        $orderStat = [
            'total' => count($orders->toArray()),
            'new' => 0,
            'progress' => 0,
            'done' => 0,
            'label' => $label
        ];
        foreach ($orders as $order) {
            $orderDate = Carbon::parse($order->created_at)->format('Y-m');
            if ($order->payment_status === Order::PAYMENT_STATUS_YES) {
                $revenue += $order->total_amount;
                $valueRevenue[$orderDate] += $order->total_amount;
            }
            if ($order->shipping_status === Order::STATUS_DONE && $order->payment_status === Order::PAYMENT_STATUS_YES) {
                $orderStat['done'] += 1;
            } elseif ($order->payment_status === Order::PAYMENT_STATUS_NO && $order->fulfillment_status === null) {
                $orderStat['new'] += 1;
            } else {
                $orderStat['progress'] += 1;
            }


            if (array_key_exists($orderDate, $valueOrder)) {
                $valueOrder[$orderDate] += 1;
            }
        }
         $orderStat['series'][] = array_values($valueOrder);
         $data = [
             'totalUser' => User::query()->where('type', 2)->count(),
             'revenue' => [
                 'total' => round($revenue / 1000),
                 'label' => $label,
                 'series' => [array_values($valueRevenue)]
             ],
             'totalProduct' => Product::query()->count() + Combo::query()->count(),
             'orderStat' => $orderStat
        ];

        return $this->responseSuccess($data);
    }
}
