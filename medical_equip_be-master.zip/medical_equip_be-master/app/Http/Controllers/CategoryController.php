<?php

namespace App\Http\Controllers;

use App\Category;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use JD\Cloudder\Facades\Cloudder;

class CategoryController extends Controller
{
    public function index(Request $request) {
        $categories = Category::query()
            ->where('type', $request->get('type', 1))
            ->paginate(parent::ITEM_PER_PAGE);
        return $this->responseSuccess($categories);
    }

    public function getAllCategory(Request $request)
    {
        $categories = Category::query()
            ->where('type', $request->get('type', 1))
            ->get();
        return $this->responseSuccess($categories->map(function ($category) {
            return [
                'id' => $category->id,
                'text' => $category->name
            ];
        }));
    }

    public function allUserCategory(Request $request)
    {
        return $this->responseSuccess(Category::query()
            ->where('type', $request->get('type', 1))
            ->get());
    }

    public function getCategory($id)
    {
        $category = $this->getCategoryById($id);
        if (empty($category)) {
            return $this->responseError('Danh mục không tồn tại', Response::HTTP_NOT_FOUND);
        }
        return $this->responseSuccess($category);
    }

    public function updateCategory(Request $request, $id)
    {
        $category = $this->getCategoryById($id);
        if (empty($category)) {
            return $this->responseError('Danh mục không tồn tại', Response::HTTP_NOT_FOUND);
        }
        $rules = [
            'name' => 'required|unique:categories,name,' . $id
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $this->saveCategory($request, $category);
        return $this->responseSuccess($this->getCategoryById($id));
    }

    public function createCategory(Request $request)
    {
        $rules = [
            'name' => 'required|unique:categories'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $category = new Category();
        $this->saveCategory($request, $category);
        return $this->responseSuccess($this->getCategoryById($category->id));
    }

    private function saveCategory(Request $request, $category)
    {
        $category->name = $request->get('name');
        $category->type = $request->get('type', Category::TYPE_PRODUCT);
        if ($request->hasFile('icon')) {
            $file = $request->icon;
            if ($category->img_public_id) {
                $this->destroyImg($category->img_public_id);
            }
            $public_id = Str::random(10);
            Cloudder::upload($file, "uploads/icons/$public_id");
            $category->icon = Cloudder::show(Cloudder::getPublicId(), ['with' => 100, 'height' => 100]);
            $category->img_public_id = "uploads/icons/$public_id";
        }
        $category->save();
    }

    public function deleteCategory($id){
        $category = $this->getCategoryById($id);
        if (empty($category)) {
            return $this->responseError('Danh mục không tồn tại', Response::HTTP_NOT_FOUND);
        }
        $this->destroyImg($category->img_public_id);
        $category->delete();
        return $this->responseSuccess([]);
    }

    private function getCategoryById($id)
    {
        return Category::query()->where('id', $id)->first();
    }
}
