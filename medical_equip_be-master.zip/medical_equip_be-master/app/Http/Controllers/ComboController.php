<?php

namespace App\Http\Controllers;

use App\Service\ComboService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class ComboController extends Controller
{
    protected $combo_service;
    protected $rule;

    public function __construct()
    {
        $this->combo_service = new ComboService();
        $this->rule = [
            'name'=> 'required|unique:combos,name',
            'price' => 'required|numeric|min:0',
            'weight' => 'required|integer|min:0',
        ];
    }

    public function getCombos(Request $request)
    {
        return $this->responseSuccess($this->combo_service->getCombos($request));
    }

    public function getCombo($id)
    {
        $combo = $this->combo_service->getCombo($id);
        if (!empty($combo)) {
            return $this->responseSuccess($combo);
        }
        return $this->responseError("Gói sản phẩm không tồn tại", Response::HTTP_NOT_FOUND);
    }

    public function createCombo(Request $request)
    {
        $validator = Validator::make($request->all(), $this->rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $new_combo = $this->combo_service->createCombo($request->all());
        $this->processUploadImage($request, $new_combo);
        return $this->responseSuccess($new_combo);
    }

    public function updateCombo(Request $request, $id)
    {
        $this->rule['name'] .= ",$id";
        $validator = Validator::make($request->all(), $this->rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $combo = $this->combo_service->getComboWithoutRelation($id);
        if (empty($combo)) {
            return $this->responseError("Gói sản phẩm không tồn tại", Response::HTTP_NOT_FOUND);
        }
        $combo = $this->combo_service->updateCombo($combo, $request->all());
        $this->processUploadImage($request, $combo);
        return $this->responseSuccess($combo);
    }

    public function deleteCombo($id)
    {
        $combo = $this->combo_service->getCombo($id);
        if (empty($combo)) {
            return $this->responseError("Gói sản phẩm không tồn tại", Response::HTTP_NOT_FOUND);
        }
        $images = array_column($combo->images->toArray(), 'id');
        $this->combo_service->deleteImages($images);
        $combo->delete();
        return $this->responseSuccess([]);
    }

    private function processUploadImage(Request $request, $combo)
    {
        $new_images = [];
        if ($request->hasFile('images')) {
            $new_images = $this->combo_service->saveImage($combo->id, $request->images);
        }

        $deleted_images = $request->get('deleted_images');
        if (!empty($deleted_images)) {
            $this->combo_service->deleteImages($deleted_images);
        }
        $avatar_id = $request->get('avatar_id');
        if (!empty($avatar_id)) {
            if (preg_match('/new_/', $avatar_id)) {
                $avatar_id = array_get($new_images, preg_replace('/new_/','', $avatar_id));
            }
            $this->combo_service->setAvatar($combo->id, $avatar_id);
        }
    }
}
