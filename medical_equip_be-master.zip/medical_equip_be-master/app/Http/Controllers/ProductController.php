<?php

namespace App\Http\Controllers;

use App\Collection;
use App\Product;
use App\Service\ProductService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;

class ProductController extends Controller
{
    private $product_service;
    private $rule;

    public function __construct(ProductService $product_service)
    {
        $this->product_service = $product_service;
        $this->rule = [
            'name' => 'required|unique:products,name',
            'category_id' => 'required|integer',
            'vendor_id' => 'required|integer',
        ];
    }

    public function getProducts(Request $request)
    {
        return $this->responseSuccess($this->product_service->getProducts($request));
    }

    public function getProduct($id)
    {
        $product = $this->product_service->getProduct($id);
        if (!empty($product)) {
            return $this->responseSuccess($product);
        }
        return $this->responseError("Sản phẩm không tồn tại", Response::HTTP_NOT_FOUND);
    }

    public function createProduct(Request $request)
    {
        set_time_limit(100);
        $validator = Validator::make($request->all(), $this->rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        DB::beginTransaction();
        try {
            list($product, $variantIds) = $this->product_service->createProduct($request->all());
            $this->processUploadImage($request, $product, $variantIds);
            DB::commit();
            return $this->responseSuccess($this->getProduct($product->id));
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            DB::rollBack();
            return $this->responseError('Lưu sản phẩm thất bại', parent::ERROR);
        }
    }

    public function updateProduct(Request $request, $id)
    {
        $this->rule['name'] .= ",$id";
        $validator = Validator::make($request->all(), $this->rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        DB::beginTransaction();
        try {
            list($product, $variantIds) = $this->product_service->saveProduct($id, $request->all());
            $this->processUploadImage($request, $product, $variantIds);
            DB::commit();
            return $this->responseSuccess($this->getProduct($product->id));
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            DB::rollBack();
            return $this->responseError('Lưu sản phẩm thất bại', parent::ERROR);
        }
    }

    public function deleteProduct($id)
    {
        $product = $this->product_service->getProduct($id);
        if (empty($product)) {
            return $this->responseError('Danh mục không tồn tại', Response::HTTP_NOT_FOUND);
        }
        DB::beginTransaction();
        try {
            $images = array_column($product->images->toArray(), 'id');
            $this->product_service->deleteImages($images);
            $product->delete();
            DB::commit();
            return $this->responseSuccess([]);
        } catch (\Exception $e) {
            DB::rollBack();
            return $this->responseError('Xóa sản phẩm thất bại', parent::ERROR);
        }
    }

    public function getCollections()
    {
        return $this->responseSuccess(Collection::all()->filter(function ($item) {
            return Str::upper($item->title) === $item->title;
        })->values()->map(function ($item) {
            return $item->only(['id', 'title']);
        }));
    }

    private function processUploadImage(Request $request, Product $product, $variantIds = [])
    {
        $new_images = [];
        if ($request->hasFile('images')) {
            $new_images = $this->product_service->saveImage($product->id, $request->images);

            foreach ($variantIds as $data) {
                list($img, $variant) = $data;
                $variant->update([
                    'image_id' => array_get($new_images, $img)
                ]);
            }
        }

        $deleted_images = $request->get('deleted_images');
        if (!empty($deleted_images)) {
            $this->product_service->deleteImages($deleted_images);
        }
        $avatar_id = $request->get('avatar_id');
        if (!empty($avatar_id)) {
            if (preg_match('/new_/', $avatar_id)) {
                $avatar_id = array_get($new_images, preg_replace('/new_/', '', $avatar_id));
            }
            $this->product_service->setAvatar($product->id, $avatar_id);
        }
    }
}
