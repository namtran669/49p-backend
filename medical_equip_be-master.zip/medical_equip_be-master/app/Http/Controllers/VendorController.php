<?php

namespace App\Http\Controllers;

use App\Vendor;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class VendorController extends Controller
{
    public function index(Request $request)
    {
        return $this->responseSuccess(Vendor::paginate(parent::ITEM_PER_PAGE));
    }

    public function getAllVendor()
    {
        return $this->responseSuccess(Vendor::all()->map(function ($vendor) {
            return [
                'id' => $vendor->id,
                'text' => $vendor->name
            ];
        }));
    }

    public function getAllVendorClient()
    {
        return $this->responseSuccess(Vendor::all());
    }

    public function show($id)
    {
        $vendor = Vendor::whereId($id)->first();
        if (empty($vendor)) {
            return $this->responseError('Nhà cung cấp không tồn tại', Response::HTTP_NOT_FOUND);
        }
        return $this->responseSuccess($vendor);
    }

    public function store(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|unique:vendors'
        ]);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }

        return $this->responseSuccess(Vendor::create($request->only(['name'])));
    }

    public function update(Request $request, $id)
    {
        $validator = Validator::make($request->all(), [
            'name' => 'required|string|unique:vendors,name,' . $id
        ]);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $vendor = Vendor::whereId($id)->first();
        $vendor->update($request->only(['name']));
        return $this->responseSuccess($vendor->refresh());
    }

    public function destroy(Request $request, $id)
    {
        Vendor::whereId($id)->delete();
        return $this->responseSuccess(Vendor::paginate(parent::ITEM_PER_PAGE));
    }
}
