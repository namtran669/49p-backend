<?php

namespace App\Http\Controllers;

use App\Service\BlogService;
use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Validator;

class BlogController extends Controller
{
    protected $blog_service;
    protected $rule;

    public function __construct()
    {
        $this->blog_service = new BlogService();
        $this->rule = [
            'name' => 'required|unique:blogs,name',
            'category_id' => 'required|integer',
            'content' => 'required'
        ];
    }

    public function getBlogs(Request $request)
    {
        return $this->responseSuccess($this->blog_service->getBlogs($request, 0));
    }

    public function getActiveBlog(Request $request)
    {
        return $this->responseSuccess($this->blog_service->getBlogs($request, 0));
    }

    public function getBlog($id)
    {
        $blog = $this->blog_service->getBlog($id);
        if (!empty($blog)) {
            return $this->responseSuccess($blog);
        }
        return $this->responseError("Bài viết không tồn tại", Response::HTTP_NOT_FOUND);
    }

    public function createBlog(Request $request)
    {
        $validator = Validator::make($request->all(), $this->rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $new_img = [];
        if ($request->hasFile('avatar')) {
            $new_img = $this->blog_service->uploadAvatar($request->avatar);
        }
        $data = array_merge($request->all(), $new_img);
        $new_blog = $this->blog_service->createBlog($data);
        return $this->responseSuccess($new_blog);
    }

    public function updateBlog(Request $request, $id)
    {
        $this->rule['name'] .= ",$id";
        $validator = Validator::make($request->all(), $this->rule);
        if ($validator->fails()) {
            return $this->responseError($validator->errors(), parent::VALIDATE_ERROR);
        }
        $blog = $this->blog_service->getBlogWithoutRelation($id);
        if (empty($blog)) {
            return $this->responseError("Bài viết không tồn tại", Response::HTTP_NOT_FOUND);
        }
        $new_img = [];
        if ($request->hasFile('avatar')) {
            $new_img = $this->blog_service->uploadAvatar($request->avatar, $blog->img_public_id ?? null);
        }
        $data = array_merge($request->all(), $new_img);
        $blog = $this->blog_service->updateBlog($blog, $data);
        return $this->responseSuccess($blog);
    }

    public function deleteBlog($id)
    {
        $blog = $this->blog_service->getBlogWithoutRelation($id);
        if (empty($blog)) {
            return $this->responseError("Bài viết không tồn tại", Response::HTTP_NOT_FOUND);
        }
        $this->destroyImg($blog->img_public_id);
        $blog->delete();
        return $this->responseSuccess([]);
    }
}
