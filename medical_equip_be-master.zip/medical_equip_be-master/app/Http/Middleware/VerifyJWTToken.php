<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;
use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class VerifyJWTToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $error_response = [
            'code' => 2,
            'message' => 'Token không chính xác',
            'data' => []
        ];
        try {
            $user = JWTAuth::toUser($request->header('Authorization'));
            if (!$user->isAdmin()) {
                return response()->json($error_response, Response::HTTP_UNAUTHORIZED);
            }
            Auth::loginUsingId($user->id);
        }catch (JWTException $e) {
            if($e instanceof \Tymon\JWTAuth\Exceptions\TokenExpiredException) {
                return response()->json($error_response, Response::HTTP_UNAUTHORIZED);
            }else if ($e instanceof \Tymon\JWTAuth\Exceptions\TokenInvalidException) {
                return response()->json($error_response, Response::HTTP_UNAUTHORIZED);
            }else{
                return response()->json($error_response, Response::HTTP_UNAUTHORIZED);
            }
        }
        return $next($request);
    }
}
