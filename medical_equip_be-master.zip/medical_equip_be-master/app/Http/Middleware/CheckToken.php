<?php

namespace App\Http\Middleware;

use App\User;
use Closure;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Auth;

class CheckToken
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        $token  = $request->header('Authorization');
        $error_response = [
            'code' => Response::HTTP_UNAUTHORIZED,
            'message' => 'Lỗi xác thực',
            'data' => []
        ];
        if (empty($token)) {
            return response()->json($error_response);
        }

        $user = User::query()->where('token', $token)->first();
        if (empty($user)) {
            return response()->json($error_response);
        }

        Auth::loginUsingId($user->id);

        return $next($request);
    }
}
