<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Blog extends Model
{
    protected $table = 'blogs';
    protected $appends = ['textContent'];

    protected $hidden = [
        'img_public_id'
    ];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function getTextContentAttribute()
    {
        return strip_tags($this->content);
    }
}
