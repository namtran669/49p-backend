<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Cart extends Model
{
    const TYPE_PRODUCT = 1;
    const TYPE_COMBO = 2;

    protected $table = 'carts';
    public $timestamps = false;

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function combo() {
        return $this->belongsTo(Combo::class, 'product_id', 'id');
    }

    public function variant()
    {
        return $this->belongsTo(Variant::class);
    }
}
