<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Combo extends Model
{
    protected $table = 'combos';
    protected $appends = ['avatar', 'type'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = [
        'img_public_id'
    ];

    public function images()
    {
        return $this->hasMany(Image::class)
            ->select('images.id', 'images.src', 'images.is_avatar', 'combo_id')
            ->orderBy('is_avatar', 'desc');
    }

    public function getAvatarAttribute()
    {
        if (!empty($this->images())) {
            return $this->images()->first()->src;
        }
        return '';
    }

    public function getTypeAttribute()
    {
        return Cart::TYPE_COMBO;
    }
}
