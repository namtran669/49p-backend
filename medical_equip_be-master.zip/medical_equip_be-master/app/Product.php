<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    protected $table = 'products';
    protected $appends = ['avatar', 'type'];

    protected $fillable = [
        'name',
        'description',
        'shopify_id',
        'vendor_id',
        'category_id',
        'is_combo',
        'discount',
        'liked',
        'price',
        'bought'
    ];

    protected $hidden = [
        'shopify_id',
    ];

    protected $casts = [
        'is_combo' => 'boolean',
        'price' => 'double'
    ];

    public function images()
    {
        return $this->hasMany(Image::class)
            ->select('images.id', 'images.src', 'images.is_avatar', 'product_id')
            ->orderBy('is_avatar', 'desc');
    }

    public function productImages()
    {
        return $this->hasMany(Image::class);
    }

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function vendor()
    {
        return $this->belongsTo(Vendor::class);
    }

    public function options()
    {
        return $this->hasMany(Option::class);
    }

    public function variants()
    {
        return $this->hasMany(Variant::class);
    }

    public function getAvatarAttribute()
    {
        if (!empty($this->images()->first())) {
            return $this->images()->first()->src;
        }
        return '';
    }

    public function getTypeAttribute()
    {
        return Cart::TYPE_PRODUCT;
    }

    public static function fullTextWildcards($term)
    {
        // removing symbols used by MySQL
        $reservedSymbols = ['-', '+', '<', '>', '@', '(', ')', '~'];
        $term = str_replace($reservedSymbols, '', $term);

        return $term;
    }
}
