<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class CollectionProduct extends Model
{
    protected $table = 'collection_product';

    public $timestamps = false;

    protected $guarded = [];
}
