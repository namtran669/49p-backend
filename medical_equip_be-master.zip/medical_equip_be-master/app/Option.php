<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Option extends Model
{
    protected $fillable = [
        'product_id',
        'shopify_id',
        'name',
        'values'
    ];

    protected $hidden = [
        'shopify_id',
    ];

    protected $casts = [
        'values' => 'array'
    ];
}
