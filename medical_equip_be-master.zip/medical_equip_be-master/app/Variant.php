<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Variant extends Model
{
    protected $fillable = [
        'product_id',
        'shopify_id',
        'title',
        'price',
        'discount',
        'option1',
        'option2',
        'option3',
        'image_id',
        'weight',
        'compare_at_price'
    ];

    protected $casts = [
        'price' => 'double'
    ];

    public function image()
    {
        return $this->belongsTo(Image::class);
    }
}
