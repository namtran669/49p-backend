<?php

namespace App\Console\Commands;

use App\Service\SyncService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class SyncProduct extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sync:product';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync product';

    protected $syncService;

    /**
     * Create a new command instance.
     *
     * @param SyncService $syncService
     */
    public function __construct(SyncService $syncService)
    {
        $this->syncService = $syncService;
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->line('Bắt đầu đồng bộ ngày ' . now()->toDateString());
        DB::beginTransaction();
        try {
            $count = $this->syncService->syncProduct();
            DB::commit();
            $this->line('Đồng bộ thành công ' . $count . ' sản phẩm');
            $this->line('-----------------------------------------------------');
        } catch (\Exception $e) {
            DB::rollBack();
            $this->line($e->getMessage());
        }
    }
}
