<?php

namespace App\Console\Commands;

use App\Service\SyncService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class SyncCollection extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'sync:collection';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Sync collection';

    protected $syncService;

    /**
     * Create a new command instance.
     *
     * @param SyncService $syncService
     */
    public function __construct(SyncService $syncService)
    {
        $this->syncService = $syncService;
        parent::__construct();
    }

    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->line('Bắt đầu đồng bộ collection ngày ' . now()->toDateString());
        DB::beginTransaction();
        try {
            $count = $this->syncService->syncCollection();
            DB::commit();
            $this->line('Đồng bộ thành công ' . $count . ' collection');
            $this->line('-----------------------------------------------------');
        } catch (\Exception $e) {
            DB::rollBack();
            $this->line('Đông bộ thất bại');
        }
    }
}
