<?php

namespace App\Console\Commands;

use App\Order;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\DB;

class UpdateOrderStatus extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'order:update-status';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Update order status';


    /**
     * Execute the console command.
     */
    public function handle()
    {
        $this->line('Bắt đầu update ngày ' . now()->toDateString());
        DB::beginTransaction();
        try {
            Order::where('payment_status', 1)
                ->where('fulfillment_status', 'fulfilled')
                ->whereDate('fulfillment_date', '<=', now()->subDays(10)->toDateString())
                ->update([
                    'shipping_status' => Order::STATUS_DONE
                ]);
        } catch (\Exception $e) {
            DB::rollBack();
            $this->line('Đông bộ thất bại');
        }
    }
}
