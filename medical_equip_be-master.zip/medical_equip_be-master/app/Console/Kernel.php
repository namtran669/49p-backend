<?php

namespace App\Console;

use Illuminate\Console\Scheduling\Schedule;
use Illuminate\Foundation\Console\Kernel as ConsoleKernel;

class Kernel extends ConsoleKernel
{
    /**
     * The Artisan commands provided by your application.
     *
     * @var array
     */
    protected $commands = [
        //
    ];

    /**
     * Define the application's command schedule.
     *
     * @param  \Illuminate\Console\Scheduling\Schedule  $schedule
     * @return void
     */
    protected function schedule(Schedule $schedule)
    {
        // $schedule->command('inspire')
        //          ->hourly();

        $schedule->command('sync:customer')->everyTenMinutes()->sendOutputTo(storage_path('logs/customer.log'));
        $schedule->command('sync:product')->everyTenMinutes()->sendOutputTo(storage_path('logs/product.log'));
        $schedule->command('sync:collection')->everyTenMinutes()->sendOutputTo(storage_path('logs/collection.log'));
        $schedule->command('sync:order')->everyTenMinutes()->sendOutputTo(storage_path('logs/order.log'));
        $schedule->command('order:update-status')->everyTenMinutes()->sendOutputTo(storage_path('logs/order-update-status.log'));
    }

    /**
     * Register the commands for the application.
     *
     * @return void
     */
    protected function commands()
    {
        $this->load(__DIR__.'/Commands');

        require base_path('routes/console.php');
    }
}
