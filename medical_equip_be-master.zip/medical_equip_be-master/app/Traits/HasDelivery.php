<?php

namespace App\Traits;


use App\Setting;
use Illuminate\Support\Facades\Cache;

trait HasDelivery
{
    protected function initDeliveryInfo()
    {
        if (!Cache::get('delivery_info')) {
            $delivery_info = json_decode(Setting::query()
                ->where('key_name', 'delivery_info')
                ->first()->value, true);

            $delivery_info = array_map(function ($item) {
                return $item['value'];
            }, $delivery_info);

            Cache::forever('delivery_info', $delivery_info);
        }
    }

}
