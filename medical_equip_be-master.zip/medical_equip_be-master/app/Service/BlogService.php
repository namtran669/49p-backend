<?php

namespace App\Service;


use App\Blog;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;
use JD\Cloudder\Facades\Cloudder;

class BlogService
{
    protected $editable_columns = [
        'name',
        'content',
        'avatar',
        'category_id',
        'is_show',
        'img_public_id'
    ];

    public function getBlogs(Request $request, $is_show = 1)
    {
        $category_id = $request->get('categoryId');
        $blogs = Blog::query();
        if (!empty($category_id)) {
            $blogs = $blogs->where('category_id', $category_id);
        }

        if ($is_show) {
            $blogs = $blogs->where('is_show', $is_show);
        }

        $blogs = $blogs
            ->orderBy('updated_at', 'desc')
            ->with('category')
            ->paginate(Controller::ITEM_PER_PAGE);

        return $blogs;
    }

    public function getBlog(int $id)
    {
        return Blog::query()
            ->where('id', $id)
            ->with('category')
            ->first();
    }

    public function getBlogWithoutRelation(int $id)
    {
        return Blog::query()->where('id', $id)->first();
    }

    public function createBlog(array $data)
    {
        $blog = new Blog();
        $this->save($blog, $data);
        return $this->getBlog($blog->id);
    }

    public function updateBlog($blog, array $data)
    {
        $this->save($blog, $data);
        return $this->getBlog($blog->id);
    }

    public function uploadAvatar(UploadedFile $file, $old_public_id = null) {
        if ($old_public_id) {
            Cloudder::delete($old_public_id);
        }
        $public_id = Str::random(10);
        Cloudder::upload($file, "uploads/blogs/$public_id");
        return [
            'img_public_id' => "uploads/blogs/$public_id",
            'avatar' => Cloudder::show("uploads/blogs/$public_id", ['with' => 700, 'height' => 700])
        ];
    }

    private function save(&$blog, $data)
    {
        foreach ($data as $key => $value) {
            if (in_array($key, $this->editable_columns)) {
                $blog->{$key} = $value;
            }
        }
        $blog->save();
    }
}
