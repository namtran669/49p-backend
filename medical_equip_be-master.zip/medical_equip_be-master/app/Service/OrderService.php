<?php

namespace App\Service;

use App\Http\Controllers\Controller;
use App\Order;
use App\OrderDetail;
use App\Product;
use App\Rank;
use App\User;
use Carbon\Carbon;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class OrderService
{

    public function getOrders(Request $request)
    {
        $orders = Order::query();
        $order_code = $request->get('orderCode');
        $order_date = $request->get('orderDate');
        $pay_method = $request->get('payMethod');
        $pay_status = $request->get('paymentStatusSearch');
        $shipping_status = $request->get('shippingStatusSearch');

        if (!empty($order_code)) {
            $orders = $orders->where('order_code', 'like', "%$order_code%");
        }
        if (!empty($order_date)) {
            $orders = $orders->whereDate('created_at', $order_date);
        }
        if (!empty($pay_method)) {
            $orders = $orders->whereIn('pay_method', $pay_method);
        }
        if (!empty($shipping_status)) {
            $orders = $orders->where('shipping_status', $shipping_status);
        }
        if (!empty($pay_status)) {
            $orders = $orders->where('payment_status', $pay_status);
        }
        $orders = $orders
            ->orderBy('created_at', 'desc')
            ->paginate(Controller::ITEM_PER_PAGE);

        return $orders;
    }

    public function getOrderDetails($id)
    {
        $order_details = OrderDetail::query()
            ->where('order_id', $id)
            ->get()
            ->toArray();

        return $order_details;
    }

    public function getOrderDetail($id)
    {
        return OrderDetail::query()
            ->where('id', $id)
            ->first();
    }

    public function getOrder($id)
    {
        return Order::query()->where('id', $id)->first();
    }

    public function getOrderByUserId(Request $request, $user_id)
    {
        $last3Month = Carbon::now()->subMonth(3)->toDateTimeString();
        $orders = Order::query()
            ->where('user_id', $user_id)
            ->where('created_at', '>=', $last3Month);

        $shippingStatus = $request->input('shippingStatus');

        if ($shippingStatus == Order::STATUS_NEW) {
            $orders = $orders->whereNull('fulfillment_status')->whereNull('cancelled_at');
        } elseif ($shippingStatus == Order::STATUS_SHIPPING) {
            $orders = $orders->where('fulfillment_status', 'fulfilled')
                ->where(function (Builder $builder) {
                    $builder->whereNull('fulfillment_date')
                        ->orWhereDate('fulfillment_date', '>', now()->subDays(10)->toDateString())
                        ->orWhere('payment_status', 0);
                })->whereNull('cancelled_at');

        } elseif ($shippingStatus == Order::STATUS_DONE) {
            $orders = $orders->where(function (Builder $builder) {
                $builder->where('payment_status', 1)
                    ->where('fulfillment_status', 'fulfilled')
                    ->whereDate('fulfillment_date', '<=', now()->subDays(10)->toDateString())
                    ->orWhereNotNull('cancelled_at');
            });
        }

        $orders = $orders->orderBy('created_at', 'desc')
            ->with('details')
            ->paginate(Controller::ITEM_PER_PAGE);

        return $orders;
    }

    /**
     * @param array $cart_content
     * @param $pay_method
     * @param $pay_status
     * @param array $payment_info
     * @return Order
     */
    public function createOrder(array $cart_content, $pay_method, $pay_status, array $payment_info)
    {
        $order = new Order();
        $order->user_id = Auth::id();
        $order->shopify_user_id = Auth::user()->shopify_id;
        $order->name = array_get($payment_info, 'name');
        $order->phone = array_get($payment_info, 'phone');
        $order->address = array_get($payment_info, 'address');
        $order->provincial = array_get($payment_info, 'provincial');
        $order->district = array_get($payment_info, 'district');
        $order->ward = array_get($payment_info, 'ward');
        $order->street = array_get($payment_info, 'address');
        $order->trans_id = array_get($payment_info, 'trans_id', null);
        $order->payment_status = $pay_status;
        $order->pay_method = $pay_method;
        $order->total_amount = $cart_content['total'];
        $order->total_discount = $cart_content['total_discount'];
        $order->point = $cart_content['point'];
        $order->gateway = Order::PAY_METHOD_NAME[$pay_method];
        $order->total_weight = $cart_content['weight'];
        $order->save();

        $details = [];
        foreach ($cart_content['items'] as $item) {
            $detail = [
                'order_id' => $order->id,
                'product_id' => $item['product_id'],
                'product_type' => $item['product_type'],
                'variant_id' => $item['variant_id'],
                'qty' => $item['qty'],
            ];

            if (!empty($item['variant_id'])) {
                $productData = $item['item']['variant'];
                $detail = array_merge($detail, [
                    'avatar' => $productData['image'] ? $productData['image']['src'] : $item['item']['avatar'],
                    'name' => $productData['title'],
                    'shopify_variant_id' => $productData['shopify_id'],
                ]);
            } else {
                $productData = $item['item'];
                $detail = array_merge($detail, [
                    'avatar' => $productData['avatar'],
                    'name' => $productData['name'],
                ]);
            }

            $details[] = array_merge($detail, [
                'price' => $productData['price'],
                'discount' => $productData['discount'],
                'total_amount' => $item['qty'] * $productData['price'],
                'subtotal_amount' => $item['qty'] * ($productData['compare_at_price'] ?? $productData['price']),
            ]);

            $product = Product::find($item['product_id']);
            if (!empty($product)) {
                $product->bought += 1;
                $product->save();
            }
        }

        OrderDetail::query()->insert($details);


        $order->order_code = sprintf('#49P%04dDM', $order->id);
        $order->save();

        return $order;
    }

    public function updateOrderPaymentStatus($order, $paymentStatus)
    {
        $order->payment_status = $paymentStatus;
        $order->save();

        if ($paymentStatus === Order::PAYMENT_STATUS_YES) {
            $this->updateTotalSpent($order);
        }
    }

    public function updateOrderShippingStatus($order, $shippingStatus)
    {
        $order->shipping_status = $shippingStatus;
        if ($shippingStatus === Order::STATUS_SHIPPING) {
            $order->shipping_date = Carbon::now()->toDateString();
        }
        $order->save();
    }

    public function deleteOrder($order_id)
    {
        OrderDetail::query()->where('order_id', $order_id)->delete();
        Order::query()->where('id', $order_id)->delete();
    }

    public function getOrderByDeliveryCode($delivery_code)
    {
        return Order::query()->where('delivery_code', $delivery_code)->first();
    }

    public function updateTotalSpent($order)
    {
        $user = User::query()->where('id', $order->user_id)->first();
        $user->point += $order->point;
        $user->total_amount_spent += $order->total_amount;
        $rank = Rank::query()
            ->where('turnover_condition', '<=', $user->total_amount_spent)
            ->orderBy('turnover_condition', 'desc')
            ->first();
        $user->rank_id = !empty($rank) ? $rank->id : 1;
        $user->save();
    }

    /**
     * @param Order $order
     * @return mixed
     */
    public function createShopifyOrder(Order $order)
    {
        if ($order->details()->whereNull('shopify_variant_id')->count() > 0) {
            return null;
        }

        $nameSegment = explode(' ', $order->name);
        $firstName = array_shift($nameSegment);
        $lastName = implode(' ', $nameSegment);
        $customer = [];
        if ($order->shopify_user_id) {
            $customer = [
                'id' => $order->shopify_user_id
            ];
        }

        $address = [
            'first_name' => $firstName,
            'last_name' => $lastName ?? $firstName,
            'address1' => $order->address,
            'phone' => $order->phone,
            'province' => $order->provincial,
            'city' => $order->provincial,
            'country' => 'Vietnam',
            'zip' => '10000'
        ];

        $data['order'] = [
            'line_items' => $order->details()
                ->selectRaw('shopify_variant_id as variant_id, qty as quantity')->get()->toArray(),
            'fulfillment_status' => null,
            'financial_status' => 'pending',
            'billing_address' => $address,
            'shipping_address' => $address,
        ];

        if (!empty($customer)) {
            $data['order']['customer'] = $customer;
        } else {
            $data['order']['email'] = optional(Auth::user()->paymentInfo)->email;
        }

        $shopifyService = new ShopifyService();
        $response = $shopifyService->createOrder($data);
        if ($response->getStatusCode() === 201) {
            return json_decode($response->getBody(), true)['order'];
        }
        return null;
    }

    public function updateShopifyOrder(Order $order, array $shopifyOrder)
    {
        $order->order_code = $shopifyOrder['name'];
        $order->shopify_id = $shopifyOrder['id'];
        $order->details()->update([
            'shopify_order_id' => $shopifyOrder['id']
        ]);
        if (!$order->user->shopify_id && array_key_exists('customer', $shopifyOrder)) {
            $order->user()->update([
                'shopify_id' => $shopifyOrder['customer']['id']
            ]);
        }
        $order->save();
    }
}
