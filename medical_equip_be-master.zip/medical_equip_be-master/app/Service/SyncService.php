<?php

namespace App\Service;

use App\Category;
use App\Collection;
use App\Image;
use App\Option;
use App\Order;
use App\Product;
use App\User;
use App\Variant;
use App\Vendor;
use Carbon\Carbon;
use Exception;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Cache;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Illuminate\Support\Str;
use Psr\Http\Message\ResponseInterface;

class SyncService
{
    const LIMIT = 250;

    protected $shopifyService;
    protected $query;
    protected $products;
    protected $orders;
    protected $categories = [];
    protected $vendors = [];

    public function __construct(ShopifyService $shopifyService)
    {
        $this->shopifyService = $shopifyService;
        $this->query = [
            'limit' => self::LIMIT
        ];

        $this->orders = [];

    }

    public function syncProduct()
    {
        $this->products = [];
        $this->categories = Category::all()->pluck('name')->toArray();
        $this->vendors = Vendor::all()->pluck('name')->toArray();
        $pages = $this->shopifyService->getProductTotalPage();
        DB::beginTransaction();
        try {
            for ($page = 1; $page <= $pages; $page++) {
                $response = $this->shopifyService->getProducts($this->query);
                $this->saveProducts(json_decode($response->getBody(), true)['products']);
                $this->resetQuery($response, $this->query);
            }
            $deletedProducts = Product::whereNotIn('shopify_id', $this->products)->whereNotNull('shopify_id');
            Variant::whereIn('product_id', $deletedProducts->pluck('id'))->delete();
            Option::whereIn('product_id', $deletedProducts->pluck('id'))->delete();
            $images = Image::whereIn('product_id', $deletedProducts->pluck('id'));

            $productService = new ProductService();
            $productService->deleteImages($images->pluck('id')->toArray());
            $images->delete();

            $deletedProducts->delete();
            Cache::forever('syncProduct', true);
            DB::commit();
            return count($this->products);
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            DB::rollBack();
            throw new Exception('Error');
        }
    }

    public function syncCustomer()
    {
        $pages = $this->shopifyService->getCustomerTotalPage();
        DB::beginTransaction();
        $customer = 0;
        try {
            for ($page = 1; $page <= $pages; $page++) {
                $response = $this->shopifyService->getCustomers($this->query);
                $this->saveCustomers(json_decode($response->getBody(), true)['customers'], $customer);
                $this->resetQuery($response, $this->query);
            }
            DB::commit();
            Cache::forever('syncCustomer', true);
            return $customer;
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            DB::rollBack();
            throw new Exception('Error');
        }
    }

    public function syncOrder()
    {
        DB::beginTransaction();
        try {
            $count = $this->syncOpenOrder();
            $this->syncDoneOrder();
            $this->syncCancelledOrder();

            DB::commit();
            return $count;
        } catch (\Exception $e) {
            Log::info($e->getMessage());
            DB::rollBack();
            throw new Exception('Error');
        }
    }

    public function syncOpenOrder()
    {
        $pages = $this->shopifyService->getOrderTotalPage(250, [
            'status' => 'open',
            'updated_at_min' => now()->subDays(7)->format('Y-m-d\TH:i:s.uP')
        ]);

        $this->query['updated_at_min'] = now()->subDays(7)->format('Y-m-d\TH:i:s.uP');

        for ($page = 1; $page <= $pages; $page++) {
            $response = $this->shopifyService->getOrders($this->query);
            $this->saveOrders(json_decode($response->getBody(), true)['orders']);
            $this->resetQuery($response, $this->query);
        }

        return count($this->orders);
    }

    public function syncDoneOrder()
    {
        $pages = $this->shopifyService->getOrderTotalPage(250, [
            'status' => 'closed',
            'updated_at_min' => now()->subDays(7)->format('Y-m-d\TH:i:s.uP')
        ]);
        $query = [
            'status' => 'closed',
            'limit' => 250,
            'updated_at_min' => now()->subDays(7)->format('Y-m-d\TH:i:s.uP')
        ];
        for ($page = 1; $page <= $pages; $page++) {
            $closedOrders = $this->shopifyService->getOrders($query);
            $this->saveOrders(json_decode($closedOrders->getBody(), true)['orders']);
            $this->resetQuery($closedOrders, $query);
        }
    }

    public function syncCancelledOrder()
    {
        $pages = $this->shopifyService->getOrderTotalPage(250, [
            'status' => 'cancelled',
            'updated_at_min' => now()->subDays(7)->format('Y-m-d\TH:i:s.uP')
        ]);

        $query = [
            'status' => 'cancelled',
            'limit' => 250,
            'updated_at_min' => now()->subDays(7)->format('Y-m-d\TH:i:s.uP')
        ];

        for ($page = 1; $page <= $pages; $page++) {
            $cancelledOrders = $this->shopifyService->getOrders($query);
            $this->saveOrders(json_decode($cancelledOrders->getBody(), true)['orders']);
            $this->resetQuery($cancelledOrders, $query);
        }
    }

    public function syncCollection()
    {
        $pages = $this->shopifyService->getCollectionTotalPage();
        DB::beginTransaction();
        try {
            $count = 0;
            for ($page = 1; $page <= $pages; $page++) {
                $response = $this->shopifyService->getCollections($this->query);
                $this->saveCollections(json_decode($response->getBody(), true)['smart_collections'], $count);
                $this->resetQuery($response, $this->query);
            }
            DB::commit();

            return $count;
        } catch (\Exception $e) {
            Log::error($e->getMessage());
            DB::rollBack();
            throw new Exception($e->getMessage());
        }
    }

    protected function resetQuery(ResponseInterface $response, array &$query)
    {
        $headers = $response->getHeaders();
        if (array_key_exists('Link', $headers)) {
            $links = explode(', ', $headers['Link'][0]);

            $nextUrl = count($links) === 1 ? $links[0] : $links[1];

            $hasNext = Str::contains($nextUrl, 'rel="next"');

            $nextUrl = str_replace('<', '', $nextUrl);
            $nextUrl = str_replace('>; rel="next"', '', $nextUrl);
            $nextUrl = parse_url($nextUrl, PHP_URL_QUERY);
            parse_str($nextUrl, $query);
            return $hasNext;
        }

        return false;
    }

    protected function saveProducts(array $products)
    {
        $products = collect($products);

        $products->each(function ($product) {
            $updated_at = Carbon::parse($product['updated_at']);
            $this->products[] = $product['id'];
//            if ($updated_at->gt(Carbon::now()->subDays(10)) || !Cache::get('syncProduct')) {
            if (!in_array($product['product_type'], $this->categories)) {
                Category::create([
                    'name' => $product['product_type']
                ]);
                $this->categories[] = $product['product_type'];
            }

            if (!in_array($product['vendor'], $this->vendors)) {
                Vendor::create([
                    'name' => $product['vendor']
                ]);
                $this->vendors[] = $product['vendor'];
            }

            $this->createProduct($product);
//            }
        });
    }

    protected function saveCustomers(array $customers, &$count)
    {
        collect($customers)->each(function ($customer) use (&$count) {
            $updated_at = Carbon::parse($customer['updated_at']);
            $count++;
            if ($updated_at->gt(Carbon::now()->subDays(2)) || !Cache::get('syncCustomer')) {
                $hasAddress = array_key_exists('default_address', $customer) && $customer['default_address']['phone'];
                if ($customer['verified_email'] && ($customer['phone'] || $hasAddress)) {
                    $phone = $hasAddress ? $customer['default_address']['phone'] : $customer['phone'];

                    $phone = $this->getValidPhone($phone);
                    if (!empty($phone)) {
                        $newUser = User::updateOrCreate(
                            ['phone' => $phone],
                            [
                                'shopify_id' => $customer['id'],
                                'name' => $hasAddress ? $customer['default_address']['name'] : $customer['first_name'],
                                'phone' => $phone,
                                'address' => $hasAddress ? $customer['default_address']['address1'] : null,
                                'total_amount_spent' => $customer['total_spent'],
                                'email' => $customer['email'],
                                'accepts_marketing' => $customer['accepts_marketing'],
                            ]
                        );

                        $newUser->channel = $newUser->channel ?? Str::random(32);
                        $newUser->save();

                        if (empty($newUser->paymentInfo) && $hasAddress) {
                            $newUser->paymentInfo()->create([
                                'name' => $customer['default_address']['name'],
                                'phone' => $phone,
                                'address' => $customer['default_address']['address1'],
                                'provincial' => $customer['default_address']['province'],
                            ]);
                        }
                    }
                }
            }

        });
    }

    protected function saveOrders(array $orders)
    {
        collect($orders)->each(function ($order) {
            $this->orders[] = $order['id'];

            if (!$order['test']) {
                $address = [];
                if (array_key_exists('billing_address', $order)) {
                    $address = [
                        'name' => $order['billing_address']['name'],
                        'phone' => $order['billing_address']['phone'],
                        'address' => $order['billing_address']['address1'],
                        'provincial' => $order['billing_address']['city'],
                    ];
                } elseif (array_key_exists('customer', $order) && array_key_exists('default_address', $order['customer'])) {
                    $address = [
                        'name' => $order['customer']['default_address']['name'],
                        'phone' => $order['customer']['default_address']['phone'],
                        'address' => $order['customer']['default_address']['address1'],
                        'provincial' => $order['customer']['default_address']['city'],
                    ];
                }

                $customerId = Arr::get($order, 'customer.id');

                $newOrder = Order::updateOrCreate(
                    ['shopify_id' => $order['id']],
                    array_merge([
                        'shopify_id' => $order['id'],
                        'order_code' => $order['name'],
                        'payment_status' => $order['financial_status'] == 'paid' ? Order::PAYMENT_STATUS_YES : Order::PAYMENT_STATUS_NO,
                        'fulfillment_status' => $order['fulfillment_status'],
                        'shipping_status' => $order['fulfillment_status'] === 'fulfilled' ? Order::STATUS_SHIPPING : Order::STATUS_NEW,
                        'total_amount' => $order['total_price'],
                        'total_discount' => $order['total_discounts'],
                        'total_weight' => $order['total_weight'],
                        'user_id' => $customerId ? optional(User::where('shopify_id', $customerId)->first())->id : null,
                        'shopify_user_id' => $customerId,
                        'gateway' => $order['gateway'],
                        'cancelled_at' => $order['cancelled_at'] ? Carbon::parse($order['cancelled_at'])->toDateTimeString() : null,
                        'cancel_reason' => $order['cancel_reason'],
                        'pay_method' => $order['gateway'] === 'Cash on Delivery (COD)' ? Order::PAY_METHOD_NORMAL : Order::PAY_METHOD_BANK
                    ], $address)
                );

                if (!$newOrder->fulfillment_date && $order['fulfillment_status'] === 'fulfilled') {
                    $newOrder->update([
                        'fulfillment_date' => now()->toDateString()
                    ]);
                }

                if ($newOrder->fulfillment_date && $newOrder->fulfillment_date <= now()->subDays(10)->toDateString()) {
                    $newOrder->update([
                        'shipping_status' => Order::STATUS_DONE
                    ]);
                }

                $newOrder->details()->delete();
                collect($order['line_items'])->each(function ($item) use ($order, $newOrder) {
                    if ($variant = Variant::where('shopify_id', $item['variant_id'])->first()) {
                        $newOrder->details()->create([
                            'product_id' => $variant->product_id,
                            'shopify_id' => $item['id'],
                            'variant_id' => $variant->id,
                            'shopify_variant_id' => $item['variant_id'],
                            'shopify_order_id' => $order['id'],
                            'shopify_product_id' => $item['product_id'],
                            'product_type' => 1,
                            'avatar' => optional($variant->image)->src,
                            'name' => $item['name'],
                            'price' => $item['price'],
                            'qty' => $item['quantity'],
                            'discount' => $item['total_discount'],
                            'subtotal_amount' => $item['quantity'] * $item['price'],
                            'total_amount' => $item['quantity'] * $item['price'] - $item['total_discount'],
                        ]);
                    }
                });
            }
        });
    }

    protected function getValidPhone($phoneNumber)
    {
        if (preg_match("/[a-z]/i", $phoneNumber) || strpos($phoneNumber, '(') !== false
            || strpos($phoneNumber, ')') !== false
            || strpos($phoneNumber, '-') !== false
            || strlen($phoneNumber) < 10) {
            return '';
        }
        $phoneNumber = str_replace(' ', '', $phoneNumber);
        $phoneNumber = substr($phoneNumber, -9);
        return '+84' . $phoneNumber;
    }

    protected function createProduct(array $product)
    {
        $titles = explode(' ', $product['title']);
        $is_combo = strtolower($titles[0]) === 'bộ' || strtolower($titles[0]) === 'combo';

        /* @var Product $newProduct */
        $newProduct = Product::updateOrCreate(
            ['shopify_id' => $product['id']],
            [
                'name' => $product['title'],
                'description' => $product['body_html'],
                'shopify_id' => $product['id'],
                'vendor_id' => $product['vendor'] ? Vendor::where('name', $product['vendor'])->first()->id : null,
                'is_combo' => $is_combo,
                'price' => $product['variants'][0]['price'],
                'category_id' => $product['product_type'] ? Category::where('name', $product['product_type'])->first()->id : null,
            ]
        );

        $newProduct->options()->delete();

        $options = collect($product['options'])->map(function ($option) {
            return [
                'shopify_id' => $option['id'],
                'name' => $option['name'],
                'values' => $option['values']
            ];
        })->toArray();

        $newProduct->options()->createMany($options);

        $newProduct->images()->delete();

        $images = collect($product['images'])->map(function ($image) use ($product) {
            return [
                'shopify_id' => $image['id'],
                'src' => $image['src'],
                'is_avatar' => $image['src'] == $product['image']['src']
            ];
        })->toArray();

        $newProduct->productImages()->createMany($images);

        $maxDiscount = 0;

        foreach ($product['variants'] as $variant) {
            $discount = !empty($variant['compare_at_price']) ? round(($variant['compare_at_price'] - $variant['price']) / $variant['compare_at_price'], 2) * 100 : 0;
            if ($discount > $maxDiscount) {
                $maxDiscount = $discount;
            }
            $newProduct->variants()->updateOrCreate(
                ['shopify_id' => $variant['id']],
                [
                    'shopify_id' => $variant['id'],
                    'title' => $variant['title'],
                    'price' => $variant['price'],
                    'compare_at_price' => $variant['compare_at_price'],
                    'discount' => $discount,
                    'option1' => $variant['option1'],
                    'option2' => $variant['option2'],
                    'option3' => $variant['option3'],
                    'image_id' => $variant['image_id'] ? Image::where('shopify_id', $variant['image_id'])->first()->id : null,
                    'weight' => $variant['weight_unit'] === 'g' ? $variant['weight'] : $variant['weight'] * 1000,
                ]
            );
        }

        $newProduct->update([
            'discount' => $maxDiscount
        ]);
    }

    protected function saveCollections(array $collections, &$count)
    {
        Collection::whereNotNull('shopify_id')->whereNotIn('shopify_id', collect($collections)->pluck('id'))->delete();
        collect($collections)->each(function ($collection) use (&$count) {
            /**@var Collection $newCollection */
            $newCollection = Collection::updateOrCreate([
                'shopify_id' => $collection['id'],
            ],
                [
                    'title' => $collection['title'],
                    'description' => $collection['body_html'],
                    'handle' => $collection['handle'],
                ]);


            $nextPage = true;
            $query = [
                'limit' => self::LIMIT
            ];

            while ($nextPage) {

                $response = $this->shopifyService->getProductByCollections($query, $collection['id']);

                $shopifyProducts = json_decode($response->getBody(), true)['products'];
                $products = Product::whereIn('shopify_id', collect($shopifyProducts)->pluck('id'))
                    ->pluck('id')->toArray();

                $newCollection->products()->attach($products);
                $nextPage = $this->resetQuery($response, $query);
            }

            $count++;
        });
    }

    public function initQuery()
    {
        $this->query = [
            'limit' => self::LIMIT
        ];
    }
}
