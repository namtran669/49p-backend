<?php

namespace App\Service;


use GuzzleHttp\Client;

class MomoService
{
    private $client;
    public function __construct()
    {
        $this->client = new Client(['base_uri' => config('momo.endpoint')]);
    }

    public function requestPayment($data) {
        $response = $this->client->post( 'pay/app', ['json' => $data]);
        return $response;
    }

    public function confirmPayment($data)
    {
        $response = $this->client->post( 'pay/confirm', ['json' => $data]);
        return $response;
    }
}
