<?php
namespace App\Service;

use App\Cart;
use App\Combo;
use App\Http\Controllers\Controller;
use App\Message;
use App\Product;
use App\User;
use App\UserPayment;
use App\UserProduct;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Str;

class UserService
{
    public $editable_columns = [];

    public function __construct()
    {
        $this->editable_columns = ['name', 'email', 'token', 'address', 'avatar', 'img_public_id'];
    }

    public function getUsers(Request $request)
    {
        $users = User::query();
        $keyword = $request->get('keyword');
        $users = $users->where('type', 2);
        if (!empty($keyword)) {
            $users = $users->where(function ($query) use ($keyword) {
                $query->where('name', 'like', "%$keyword%")
                    ->orWhere('phone', 'like', "%$keyword%");
            });
        }
        $users = $users
            ->with('rank')
            ->paginate(Controller::ITEM_PER_PAGE);

        return $users;
    }

    public function getUserForChat(Request $request)
    {
        $message = Message::query()
            ->selectRaw('id, user_id, message, max(created_at) as created_at')
            ->groupBy('user_id')
            ->toSql();

        $unreadMessage = Message::query()
            ->selectRaw('channel, user_id, count(*) as unread')
            ->where('is_read', 0)
            ->where('user_id', '<>', config('myconfig.adminId'))
            ->groupBy('user_id')
            ->pluck('unread', 'channel')
            ->toArray();

        $users = User::query()
            ->selectRaw('users.id, phone, name, avatar, channel, DATE_FORMAT(messages.created_at, "%Y-%m-%d %H:%i") as last_message_date')
            ->where('type', 2)
            ->leftJoin(DB::raw("($message) messages" ), function($join) {
                $join->on('users.id', '=', 'messages.user_id');
            })->orderBy('messages.created_at', 'desc')
            ->orderBy('id')
            ->paginate(Controller::ITEM_PER_PAGE);

        $data = [
            'data' => $users->items(),
            'unread' => $unreadMessage,
            'last_page' => $users->lastPage()
        ];
        return $data;
    }

    public function getUser($id)
    {
        $user = User::query()
            ->where('id', $id)
            ->with('rank')
            ->with('paymentInfo')
            ->first();

        return $user;
    }

    public function getUserByPhone($phone)
    {
        $phone = substr($phone, -9);
        $user = User::query()
            ->where('phone', 'like', "%$phone")
            ->where('type', 2)
            ->with('rank')
            ->first();

        return $user;
    }

    public function createUser($phone)
    {
        $user = new User();
        $user->phone = $phone;
        $user->token = Str::random(64);
        $user->channel = Str::random(32);
        $user->save();

        $user_payment = new UserPayment();
        $user_payment->user_id = $user->id;
        $user_payment->phone = $phone;
        $user_payment->save();

        return $this->getUser($user->id);
    }

    public function updateUser(int $user_id, array $data)
    {
        $user = $this->getUser($user_id);
        foreach ($data as $key => $value) {
            if (in_array($key, $this->editable_columns)) {
                $user->{$key} = $value;
            }
        }
        $user->save();
        return $this->getUser($user_id);
    }

    public function getFavoriteProduct($user_id)
    {
        $products = Product::query()
            ->join('product_user', 'products.id', '=', 'product_user.product_id')
            ->where('user_id', $user_id)
            ->where('product_type', Cart::TYPE_PRODUCT)
            ->with('images')
            ->selectRaw('products.*, product_user.id as favorite_id')
            ->get()
            ->toArray();

        $combos = Combo::query()
            ->join('product_user', 'combos.id', '=', 'product_user.product_id')
            ->where('user_id', $user_id)
            ->where('product_type', Cart::TYPE_COMBO)
            ->with('images')
            ->selectRaw('combos.*, product_user.id as favorite_id')
            ->get()
            ->toArray();

        return array_merge($products, $combos);

    }

    public function addFavoriteProduct($product_id, $product_type, $user_id)
    {
        $product_favorite = UserProduct::query()
            ->where('user_id', $user_id)
            ->where('product_id', $product_id)
            ->where('product_type', $product_type)
            ->first();
        $data_insert = [];
        if (empty($product_favorite)) {
            $data_insert[] = [
                'product_id' => $product_id,
                'user_id' => $user_id,
                'product_type' => $product_type,
            ];
            UserProduct::query()->insert($data_insert);
            if ($product_type === Cart::TYPE_PRODUCT) {
                $product = Product::query()->where('id', $product_id)->first();
            } else {
                $product = Combo::query()->where('id', $product_id)->first();
            }

            $product->liked += 1;
            $product->save();
        }
    }

    public function deleteFavoriteProduct($id, $user_id)
    {
        $user_product = UserProduct::query()
            ->where('user_id', $user_id)
            ->where('id', $id)
            ->first();
        if (!empty($user_product)) {
            $product = $user_product->product_type === Cart::TYPE_PRODUCT ? Product::query() : Combo::query();
            $product = $product->where('id', $user_product->product_id)->first();
            $product->liked -= 1;
            $product->save();
            $user_product->delete();
        }
    }

    public function updatePaymentInfo(array $data, $user_id)
    {
        $user_payment = UserPayment::query()->where('user_id', $user_id)->first();
        if (empty($user_payment)) {
            $user_payment = new UserPayment();
            $user_payment->user_id = $user_id;
        }
        $user_payment->phone = array_get($data, 'phone', '');
        $user_payment->email = array_get($data, 'email', '');
        $user_payment->name = array_get($data, 'name', '');
        $user_payment->address = array_get($data, 'address', '');
        $user_payment->provincial = array_get($data, 'provincial', '');
        $user_payment->district = array_get($data, 'district', '');
        $user_payment->street = array_get($data, 'street', '');
        $user_payment->ward = array_get($data, 'ward', '');
        $user_payment->save();
        return $user_payment;
    }

    public function getProductHistory($orderBySum = false)
    {
        $products = $this->getBuilder(Cart::TYPE_PRODUCT, $orderBySum);
        $combos = $this->getBuilder(Cart::TYPE_COMBO, $orderBySum);
        return array_merge($products, $combos);
    }

    private function getBuilder($type, $orderBySum = false)
    {
        $builder = $type === Cart::TYPE_PRODUCT ? Product::query()->with(['variants', 'category', 'vendor', 'options']) : Combo::query();
        $table = $type === Cart::TYPE_PRODUCT ? 'products' : 'combos';
        $builder->join('order_details', 'order_details.product_id', '=', $table .'.id')
            ->where('product_type', $type)
            ->join('orders', 'orders.id', '=', 'order_details.order_id')
            ->where('user_id', Auth::id())
            ->selectRaw("$table.*");

        if ($orderBySum) {
            $builder = $builder->selectRaw('sum(qty) as total_qty');
        }
        $builder = $builder->groupBy('product_id', 'product_type');
        if ($orderBySum) {
            $builder = $builder->orderBy('total_qty', 'desc');
        } else {
            $builder = $builder->orderBy('orders.created_at', 'desc');
        }
        return $builder->limit(50)
            ->with('images')
            ->get()
            ->toArray();
    }
}
