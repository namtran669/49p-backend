<?php

namespace App\Service;


use App\Http\Controllers\Controller;
use App\Message;
use Illuminate\Support\Str;

class ChatService
{
    public function getMessagesByChannel($channel, $lastId = null)
    {
        $channelMessages = Message::query()
            ->where('channel', $channel);
        if (!empty($lastId)) {
            $channelMessages = $channelMessages->where('id', '<', $lastId);
        }
        $channelMessages = $channelMessages->orderBy('created_at', 'desc')
            ->limit(Controller::ITEM_PER_PAGE)
            ->get();

        $this->readMessage($channel);
        return $channelMessages;
    }

    public function createChannel($user) {
        $channel = Str::random(32);
        $user->channel = $channel;
        $user->save();
        return $channel;
    }

    public function createMessage($channel, $messageContent, $user_id)
    {
        $this->readMessage($channel);
        $message = new Message();
        $message->user_id = $user_id;
        $message->channel = $channel;
        $message->message = $messageContent;
        $message->save();

        return $message;
    }

    private function readMessage($channel)
    {
        Message::query()->where('channel', $channel)
            ->update(['is_read' => 1]);
    }

    public static function getUnreadMessageCount()
    {
        return Message::query()
            ->where('is_read', 0)
            ->where('user_id', '<>', config('myconfig.adminId'))
            ->count();
    }
}
