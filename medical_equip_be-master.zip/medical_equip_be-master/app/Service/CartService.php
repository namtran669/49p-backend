<?php

namespace App\Service;


use App\Cart;
use Illuminate\Support\Facades\Auth;

class CartService
{
    public function getCarts()
    {
        $carts = Cart::query()
            ->where('user_id', Auth::id())
            ->get();
        $cart_contents = [];
        $subtotal = 0;
        $point = 0;
        $weight = 0;
        $totalDiscount = 0;
        foreach ($carts as $key => $cart) {
            $cart_item = $cart->toArray();
            if ($cart->product_type === Cart::TYPE_PRODUCT) {
                $cart_item['item'] = $cart->product;
                $item = $cart_item['item']['variant'] = $cart->variant->load('image')->toArray();
            } else {
                $item = $cart_item['item'] = optional($cart->combo)->toArray();
            }
            $cart_contents[] = $cart_item;

            $subtotal += $cart_item['qty'] * $item['price'];
            $point += $cart_item['item']['point'];
            $weight += $cart_item['qty'] * $item['weight'];
            $totalDiscount += $item['compare_at_price'] ? $item['compare_at_price'] - $item['price'] : 0;
        }
        $cart_data = [
            'items' => $cart_contents,
            'total' =>  $subtotal, //round($subtotal * (100 - Auth::user()->rank->discount) / 100),
            'subtotal' => $subtotal,
            'total_discount' => $totalDiscount,
            'point' => $point,
            'weight' => $weight ?? 0.5
        ];

        return $cart_data;
    }

    public function getCartItem(int $id)
    {
        return Cart::query()->where('id', $id)->with('product')->first();
    }

    public function getCartItemByProduct($product_id, $product_type, $variant_id = null)
    {
        $cart = Cart::query()
            ->where('product_id', $product_id)
            ->where('product_type', $product_type)
            ->where('user_id', Auth::id());
        if ($variant_id) {
            $cart->where('variant_id', $variant_id);
        }
        return $cart->first();
    }

    public function addCartItem(int $product_id, int $product_type, int $qty, $variant_id)
    {
        $cart = new Cart();
        $cart->user_id = Auth::id();
        $cart->product_id = $product_id;
        $cart->product_type = $product_type;
        $cart->variant_id = $variant_id;
        $cart->qty = $qty;
        $cart->save();
    }

    public function updateCartItem(&$cart, int $qty, $is_add = false)
    {
        if ($is_add) {
            $cart->qty += $qty;
        } else {
            $cart->qty = $qty;
        }

        $cart->save();
    }

    public function deleteCartItem(int $id)
    {
        Cart::query()->where('id', $id)->delete();
    }

    public function destroyCart()
    {
        Cart::query()->where('user_id', Auth::id())->delete();
    }
}
