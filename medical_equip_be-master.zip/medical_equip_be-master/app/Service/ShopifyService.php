<?php

namespace App\Service;

use GuzzleHttp\Client;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Log;

class ShopifyService
{
    protected $client;

    const ORDER = 'orders';
    const PRODUCT = 'products';
    const CUSTOMER = 'customers';
    const COLLECTION = 'smart_collections';

    public function __construct()
    {
        $this->client = new Client(['base_uri' => config('shopify.endpoint')]);
    }

    /**
     * @param $query
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function getProducts($query)
    {
        return $this->client->get('products.json', [
            'query' => $query,
        ]);
    }

    public function getProduct($id)
    {
        return json_decode($this->client->get("products/$id.json")->getBody(), true)['product'];
    }

    /**
     * @param $query
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function getCustomers($query)
    {
        return $this->client->get('customers.json', [
            'query' => $query,
        ]);
    }

    /**
     * @param $query
     * @return \Psr\Http\Message\ResponseInterface
     */
    public function getOrders($query)
    {
        return $this->client->get('orders.json', [
            'query' => $query,
        ]);
    }

    public function createOrder($data)
    {
        return $this->client->post('orders.json', [
            'json' => $data,
        ]);
    }

    public function getCollections($query)
    {
        return $this->client->get('smart_collections.json', [
            'query' => $query,
        ]);
    }

    public function getProductByCollections($query, $collection_id)
    {
        return $this->client->get("collections/$collection_id/products.json", [
            'query' => $query,
        ]);
    }

    public function deleteOrder($id)
    {
        return $this->client->delete("orders/$id.json");
    }

    public function getProductTotalPage($limit = SyncService::LIMIT)
    {
        return $this->getTotalPage(self::PRODUCT, $limit);
    }

    public function getCustomerTotalPage($limit = SyncService::LIMIT)
    {
        return $this->getTotalPage(self::CUSTOMER, $limit);
    }

    public function getOrderTotalPage($limit = SyncService::LIMIT, $query = [])
    {
        return $this->getTotalPage(self::ORDER, $limit, $query);
    }

    public function getCollectionTotalPage($limit = SyncService::LIMIT)
    {
        return $this->getTotalPage(self::COLLECTION, $limit);
    }

    protected function getTotalPage($resource, $limit, $query = [])
    {
        $response = $this->client->get($resource . '/count.json', [
            'query' => $query
        ]);
        $count = 0;
        if ($response->getStatusCode() === Response::HTTP_OK) {
            $count = json_decode($response->getBody(), true)['count'];
        }
        Log::info($query);
        return ceil($count / $limit);
    }
}
