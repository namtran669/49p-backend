<?php

namespace App\Service;


use App\Combo;
use App\ComboProduct;
use App\Http\Controllers\Controller;
use App\Image;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Str;
use JD\Cloudder\Facades\Cloudder;

class ComboService
{
    protected $editable_columns = [
        'name',
        'price',
        'description',
        'discount',
        'weight'
//        'point'
    ];

    public function getCombos(Request $request)
    {
        $combos = Combo::query()
            ->with('images')
            ->paginate(Controller::ITEM_PER_PAGE);

        return $combos;
    }

    public function getComboWithoutRelation(int $id)
    {
        return Combo::query()->where('id', $id)
            ->first();
    }

    public function getCombo(int $id)
    {
        return Combo::query()->where('id', $id)
            ->with('images')
            ->first();
    }

    public function createCombo(array $data)
    {
        $combo = new Combo();
        $this->save($combo, $data);
        return $this->getCombo($combo->id);
    }

    public function updateCombo($combo, array $data)
    {
        $this->save($combo, $data);
        return $this->getCombo($combo->id);
    }

    public function saveImage(int $combo_id, $files)
    {
        $image_ids = [];
        foreach ($files as $file) {
            $public_id = 'uploads/combos/' . Str::random(10);
            Cloudder::upload($file, $public_id);
            $image = new Image();
            $image->src = Cloudder::show($public_id);
            $image->img_public_id = $public_id;
            $image->combo_id = $combo_id;
            $image->save();
            $image_ids[] = $image->id;
        }
        return $image_ids;
    }

    public function deleteImages(array $image_ids)
    {
        $images = Image::query()
            ->whereIn('id', $image_ids);

        $image_public_ids = $images
            ->pluck('img_public_id')
            ->toArray();
        Cloudder::destroyImages($image_public_ids);

        $images->delete();
    }

    public function setAvatar($combo_id, $avatar_id)
    {
        $avatar = Image::query()
            ->where('combo_id', $combo_id)
            ->where('is_avatar', 1)
            ->first();
        if (!empty($avatar)) {
            $avatar->is_avatar = 0;
            $avatar->save();
        }
        $new_avatar = Image::query()
            ->where('id', $avatar_id)
            ->first();
        if (!empty($new_avatar)) {
            $new_avatar->is_avatar = 1;
            $new_avatar->save();
        }
    }

    private function save(&$combo, $data)
    {
        foreach ($data as $key => $value) {
            if (in_array($key, $this->editable_columns)) {
                $combo->{$key} = $value;
            }
        }
        $combo->save();
    }
}
