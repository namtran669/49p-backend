<?php

namespace App\Service;


use App\CollectionProduct;
use App\Http\Controllers\Controller;
use App\Image;
use App\Product;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Str;
use JD\Cloudder\Facades\Cloudder;

class ProductService
{
    protected $editable_columns = [
        'name',
        'description',
        'shopify_id',
        'vendor_id',
        'category_id',
        'is_combo',
        'liked'
//        'point'
    ];

    public function getProducts(Request $request)
    {
        $category = $request->input('categoryIds');
        $collections = $request->input('collectionIds');
        $name = $request->input('name');
        $vendor = $request->input('vendorIds');
        $priceFrom = $request->input('priceFrom');
        $priceTo = $request->input('priceTo');
        $isCombo = $request->input('isCombo');
        $isSale = $request->input('isSale');
        $orderBy = $request->input('orderBy');

        $products = Product::query();

        if (!empty($category)){
            $products = $products->whereIn('category_id', explode(',', $category));
        }

        if (!empty($name)) {
            $text_search = Product::fullTextWildcards($name);
            $products = $products->selectRaw("*, (MATCH (name) AGAINST ('$text_search' IN NATURAL LANGUAGE MODE)) as relevance")
                ->where(function (Builder $builder) use ($name, $text_search) {
                    $builder->orWhere('name', 'like', "%$name%")
                        ->orWhereRaw("MATCH (name) AGAINST (? IN NATURAL LANGUAGE MODE)", $text_search);
                })->orderByDesc('relevance');
        }

        if (!empty($vendor)) {
            $products = $products->whereIn('vendor_id', explode(',', $vendor));
        }

        if (!empty($priceFrom)) {
            $products = $products->where('price', '>=', $priceFrom);
        }

        if (!empty($priceTo)) {
            $products = $products->where('price', '<=', $priceTo);
        }

        if (!empty($isCombo)) {
            $products = $products->where('is_combo', 1);
        }

        if (!empty($isSale)) {
            $products = $products->where('discount', '>', 0);
        }

        if (!empty($collections)) {
            $collections = collect(explode(',', $collections))->map(function ($item) {
                return intval($item);
            });

            $products = $products->leftjoin('collection_product', 'products.id', '=', 'collection_product.product_id')
                ->whereIn('collection_product.collection_id', $collections);
        }

        if (!empty($orderBy)) {
            foreach (explode(';', $orderBy) as $item) {
                $itemSegment = explode(',', $item);
                $products = $products->orderBy($itemSegment[0], $itemSegment[1]);
            }
        }

        $products = $products
            ->with('images')
            ->with('category')
            ->with('vendor')
            ->with('variants')
            ->with('options')
            ->paginate(Controller::ITEM_PER_PAGE);

        return $products;
    }

    public function getProduct($id)
    {
        return Product::where('id', $id)
            ->with('images')
            ->with('variants')
            ->with('options')
            ->first();
    }

    public function createProduct(array $data)
    {
        $product = new Product();
        $variantId = $this->save($product, $data);
        return [
            $this->getProduct($product->id),
            $variantId
        ];
    }

    public function saveProduct(int $product_id, array $data)
    {
        $product = $this->getProduct($product_id);
        $variantId = $this->save($product, $data);
        return [
            $this->getProduct($product->id),
            $variantId
        ];
    }

    public function saveImage(int $product_id, $files)
    {
        $image_ids = [];
        foreach ($files as $file) {
            $public_id = 'uploads/products/' . Str::random(10);
            Cloudder::upload($file, "$public_id");
            $image = new Image();
            $image->src = Cloudder::show($public_id);
            $image->img_public_id = $public_id;
            $image->product_id = $product_id;
            $image->save();
            $image_ids[] = $image->id;
        }
        return $image_ids;
    }

    public function deleteImages(array $image_ids)
    {
        $images = Image::query()
            ->whereIn('id', $image_ids);

        $image_public_ids = $images
            ->pluck('img_public_id')
            ->toArray();
        if (!empty($image_public_ids)) {
            Cloudder::destroyImages($image_public_ids);
        }

        $images->delete();
    }

    public function setAvatar($product_id, $avatar_id)
    {
        $avatar = Image::query()
            ->where('product_id', $product_id)
            ->where('is_avatar', 1)
            ->first();
        if (!empty($avatar)) {
            $avatar->is_avatar = 0;
            $avatar->save();
        }
        $new_avatar = Image::query()
            ->where('id', $avatar_id)
            ->first();
        if (!empty($new_avatar)) {
            $new_avatar->is_avatar = 1;
            $new_avatar->save();
        }
    }


    private function save(Product &$product, $data)
    {
        foreach ($data as $key => $value) {
            if (in_array($key, $this->editable_columns)) {
                $product->{$key} = $value;
            }
        }
        $product->save();

        if (array_key_exists('options', $data)) {
            $optionIds = collect($data['options'])->pluck('id')
                ->reject(function ($item) {
                    return $item == 0;
                });
            $product->options()->whereNotIn('id', $optionIds)->delete();
            foreach ($data['options'] as $option) {
                $product->options()->updateOrCreate(
                    ['id' => array_get($option, 'id', 0)],
                    [
                        'name' => $option['name'],
                        'values' => explode(',', $option['values'])
                    ]
                );
            }
        }

        $variantImg = [];
        if (array_key_exists('variants', $data)) {
            $variantIds = collect($data['variants'])->pluck('id')
                ->reject(function ($item) {
                    return $item == 0;
                });
            $product->variants()->whereNotIn('id', $variantIds)->delete();
            foreach ($data['variants'] as $variant) {
                $variantUpdate = $product->variants()->updateOrCreate(
                    ['id' => array_get($variant, 'id', 0)],
                    [
                        'price' => $variant['price'],
                        'compare_at_price' => $variant['compare_at_price'],
                        'discount' => $variant['discount'],
                        'weight' => $variant['weight'],
                        'option1' => $variant['option1'],
                        'option2' => $variant['option2'],
                        'option3' => $variant['option3'],
                        'title' => implode(' / ', array_filter([$variant['option1'], $variant['option2'], $variant['option3']], function ($item) {
                            return !empty($item) && $item != 'null';
                        })),
                        'image_id' => is_numeric($variant['image_id']) ? $variant['image_id'] : null
                    ]
                );

                if (!is_numeric($variant['image_id'])) {
                    $variantImg[$variantUpdate->id] = [
                        str_replace('new_', '', $variant['image_id']),
                        $variantUpdate
                    ];
                }
            }
        }

        return $variantImg;
    }

}
