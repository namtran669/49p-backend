<?php

namespace App\Service;


use App\Traits\HasDelivery;
use GuzzleHttp\Client;
use Illuminate\Http\Response;

class DeliveryService
{
    use HasDelivery;

    private $token;
    private $client;

    public function __construct()
    {
        $this->token = config('delivery.token');
        $this->client = new Client(['base_uri' => config('delivery.endpoint')]);
        $this->initDeliveryInfo();
    }

    public function registerOrder($order)
    {
        $response = $this->client->post( 'services/shipment/order', [
            'json' => $order,
            'headers' => [
                'token' => $this->token
            ]
        ]);
        if ($response->getStatusCode() === Response::HTTP_OK) {
            return json_decode($response->getBody(), true);
        }
        return [];
    }

    public function getShippingFee($data)
    {
        $response = $this->client->get( 'services/shipment/fee', [
            'query' => $data,
            'headers' => [
                'token' => $this->token
            ]
        ]);
        if ($response->getStatusCode() === Response::HTTP_OK) {
            return json_decode($response->getBody(), true);
        }
        return [];
    }

    public function cancelOrder($orderLabel)
    {
        $response = $this->client->post( 'services/shipment/cancel/' . $orderLabel, [
            'headers' => [
                'token' => $this->token
            ]
        ]);
        if ($response->getStatusCode() === Response::HTTP_OK) {
            return json_decode($response->getBody(), true);
        }
        return [];
    }
}
