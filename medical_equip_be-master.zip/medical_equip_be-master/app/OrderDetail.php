<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class OrderDetail extends Model
{
    protected $table = 'order_details';

    protected $fillable = [
        'order_id',
        'product_id',
        'product_type',
        'avatar',
        'name',
        'price',
        'qty',
        'discount',
        'subtotal_amount',
        'total_amount',
        'variant_id',
        'shopify_variant_id',
        'shopify_product_id',
        'shopify_order_id',
        'shopify_id'
    ];

    protected $casts = [
        'price' => 'double',
        'total_amount' => 'double',
        'subtotal_amount' => 'double',
    ];

    protected $hidden = [
        'shopify_variant_id',
        'shopify_product_id',
        'shopify_order_id',
        'shopify_id'
    ];

    public $timestamps = false;

    public function product()
    {
        return $this->belongsTo(Product::class);
    }

    public function combo()
    {
        return $this->belongsTo(Combo::class, 'product_id', 'id');
    }

    public function order()
    {
        return $this->belongsTo(Order::class);
    }

    public function variant()
    {
        return $this->belongsTo(Variant::class);
    }
}
