<?php

use App\Rank;
use Illuminate\Database\Seeder;

class RankSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Rank::query()->truncate();
        $this->ranks()->each(function ($rank) {
            Rank::create($rank);
        });
    }

    private function ranks()
    {
        return collect([
            [
               'name' => 'Siliver',
               'turnover_condition' => 0,
               'discount' => 0
            ],
            [
                'name' => 'Titanium',
                'turnover_condition' => 0,
                'discount' => 0
            ],
            [
                'name' => 'Gold',
                'turnover_condition' => 0,
                'discount' => 0
            ],
            [
                'name' => 'Diamond',
                'turnover_condition' => 0,
                'discount' => 0
            ],
            [
                'name' => 'Platinum',
                'turnover_condition' => 0,
                'discount' => 0
            ]
        ]);
    }
}
