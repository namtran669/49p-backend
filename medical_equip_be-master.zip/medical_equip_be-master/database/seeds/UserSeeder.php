<?php

use App\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class UserSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::query()->truncate();
        $user = [
            'name' => 'Admin',
            'email' => 'admin@gmail.com',
            'type' => 1,
            'password' => Hash::make('abcd@1234'),
        ];

        User::create($user);
    }
}
