<?php

use App\Setting;
use Illuminate\Database\Seeder;

class SettingSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Setting::query()->truncate();
        $this->settings()->each(function ($item) {
            Setting::create($item);
        });
    }

    private function settings()
    {
        return collect([
            [
               'name' => 'Liên hệ',
               'key_name' => 'contact',
               'value' => null,
               'rule' => json_encode([
                   'frontend' => '',
                   'backend' => '',
               ])
            ],
            [
                'name' => 'Thông tin lấy hàng',
                'key_name' => 'delivery_info',
                'value' => json_encode([
                    'pick_name' => [
                        'name' => 'Tên người liên hệ lấy hàng',
                        'value' => ''
                    ],
                    'pick_address' => [
                        'name' => 'Địa chỉ lấy hàng',
                        'value' => ''
                    ],
                    'pick_province' => [
                        'name' => 'Tỉnh/Thành phố',
                        'value' => ''
                    ],
                    'pick_district' => [
                        'name' => 'Quận/Huyện',
                        'value' => ''
                    ],
                    'pick_tel' => [
                        'name' => 'Số điện thoại liên hệ lấy hàng',
                        'value' => ''
                    ]
                ]),
                'rule' => json_encode([
                    'frontend' => [
                        'pick_name' => 'required',
                        'pick_address' => 'required',
                        'pick_province' => 'required',
                        'pick_district' => 'required',
                        'pick_tel' => 'required'
                    ],
                    'backend' => [
                        'pick_name' => 'required',
                        'pick_address' => 'required',
                        'pick_province' => 'required',
                        'pick_district' => 'required',
                        'pick_tel' => 'required'
                    ]
                ]),
                'is_object' => 1
            ],
        ]);
    }
}
