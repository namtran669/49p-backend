<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AlterUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->boolean('accepts_marketing')->default(false);
            $table->bigInteger('shopify_id')->nullable();
            $table->decimal('total_amount_spent', 20, 2)->default(0)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('users', function (Blueprint $table) {
            $table->dropColumn('accepts_marketing');
            $table->dropColumn('shopify_id');
            $table->float('total_amount_spent')->default(0)->change();
        });
    }
}
