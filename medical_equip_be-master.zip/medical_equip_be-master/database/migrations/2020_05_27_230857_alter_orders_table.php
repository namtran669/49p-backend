<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterOrdersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->bigInteger('shopify_id')->nullable();
            $table->bigInteger('shopify_user_id')->nullable();
            $table->integer('total_weight')->nullable();
            $table->string('fulfillment_status', 30)->nullable();
            $table->bigInteger('user_id')->nullable()->change();
            $table->string('gateway')->nullable();
            $table->decimal('total_amount', 15, 2)->default(0)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('orders', function (Blueprint $table) {
            $table->dropColumn([
                'shopify_id',
                'shopify_user_id',
                'total_weight',
                'fulfillment_status',
                'gateway'
            ]);
            $table->integer('user_id')->change();
            $table->float('total_amount')->default(0)->change();
        });
    }
}
