<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateUsersTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('users', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name')->nullable();
            $table->string('phone', 20)->unique();
            $table->string('address')->nullable();
            $table->string('avatar')->nullable();
            $table->string('img_public_id', 100)->nullable();
            $table->float('total_amount_spent')->default(0);
            $table->integer('point')->default(0);
            $table->integer('rank_id')->default(1);
            $table->string('email', 100)->nullable();
            $table->boolean('type')->default(2);
            $table->string('channel', 32)->nullable();
            $table->string('password')->nullable();
            $table->string('token', 64)->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('users');
    }
}
