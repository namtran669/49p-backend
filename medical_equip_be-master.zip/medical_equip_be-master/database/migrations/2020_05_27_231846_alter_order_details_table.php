<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class AlterOrderDetailsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::table('order_details', function (Blueprint $table) {
            $table->bigInteger('variant_id')->nullable();
            $table->bigInteger('shopify_variant_id')->nullable();
            $table->bigInteger('shopify_product_id')->nullable();
            $table->bigInteger('shopify_order_id')->nullable();
            $table->bigInteger('shopify_id')->nullable();
            $table->decimal('price', 15, 2)->default(0)->change();
            $table->decimal('subtotal_amount', 15, 2)->default(0)->change();
            $table->decimal('total_amount', 15, 2)->default(0)->change();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('order_details', function (Blueprint $table) {
            $table->dropColumn([
                'variant_id',
                'shopify_variant_id',
                'shopify_product_id',
                'shopify_order_id',
                'shopify_id',
            ]);
            $table->float('price')->default(0)->change();
            $table->float('subtotal_amount')->default(0)->change();
            $table->float('total_amount')->default(0)->change();
        });
    }
}
